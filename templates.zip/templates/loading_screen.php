<div id="loading-container" class="preloader">
    <div id="loading-screen">
        <div class="loader loader-lg"></div>
    </div>
</div>