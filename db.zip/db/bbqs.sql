-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2024 at 08:25 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbqs`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblbrgy_info`
--

CREATE TABLE `tblbrgy_info` (
  `id` int(11) NOT NULL,
  `province` varchar(100) DEFAULT NULL,
  `town` varchar(100) DEFAULT NULL,
  `brgy_name` varchar(50) DEFAULT NULL,
  `number` varchar(50) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `city_logo` varchar(100) DEFAULT NULL,
  `brgy_logo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblbrgy_info`
--

INSERT INTO `tblbrgy_info` (`id`, `province`, `town`, `brgy_name`, `number`, `text`, `image`, `city_logo`, `brgy_logo`) VALUES
(1, 'Lanao del Norte ', 'Iligan City', 'Barangay Buru-un', '09265986032', 'Buru-un  is a barangay of Iligan City in the province of Lanao del Norte within Region 10 (Northern Mindanao), Philippines.', '15092024035002BB123.png', '15092024035002iligan.png', '15092024035002bbic1.png');

-- --------------------------------------------------------

--
-- Table structure for table `tblchairmanship`
--

CREATE TABLE `tblchairmanship` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblchairmanship`
--

INSERT INTO `tblchairmanship` (`id`, `title`) VALUES
(5, 'Committee on Health'),
(6, 'Committee on Education'),
(7, 'Committee on Rules'),
(8, 'Committee on Infra'),
(9, 'Committee on Solid Waste'),
(10, 'Committee on Sports'),
(12, 'No Chairmanship');

-- --------------------------------------------------------

--
-- Table structure for table `tblofficials`
--

CREATE TABLE `tblofficials` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `chairmanship` varchar(50) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `termstart` date DEFAULT NULL,
  `termend` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `contact_number` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblofficials`
--

INSERT INTO `tblofficials` (`id`, `name`, `chairmanship`, `position`, `termstart`, `termend`, `status`, `contact_number`) VALUES
(4, 'Brad Enoy', '11', '7', '2021-04-03', '2025-12-31', 'Active', '0'),
(5, 'TATA CALLENO', '11', '8', '2021-04-03', '2025-12-31', 'Active', '0'),
(6, 'ALAN BARINQUE', '11', '9', '2021-04-03', '2025-12-31', 'Active', '0'),
(7, 'JAN NIKKO GERASTA', '11', '10', '2021-04-03', '2025-12-31', 'Active', '0'),
(11, 'KARL LACIDA', '11', '14', '2021-04-03', '2025-12-31', 'Active', '0'),
(14, 'MARIANITA B. PARADELA', '2', '4', '2024-09-15', '2025-12-31', 'Active', '0'),
(17, 'MARIANITA B. PARADELA', '12', '4', '2024-09-01', '2025-12-31', 'Active', ' 912 345 6789'),
(18, 'ALAN BARINQUE', '12', '7', '2024-09-01', '2025-12-31', 'Active', '917 234 5678'),
(19, 'TATA CALLENO', '12', '8', '2024-09-01', '2025-12-31', 'Active', '927 456 7890'),
(20, 'Brad Enoy', '12', '9', '2024-09-01', '2025-12-31', 'Inactive', '939 876 5432'),
(21, 'KARL LACIDA', '12', '14', '2024-09-01', '2025-12-31', 'Active', '998 765 4321'),
(24, 'Janrey', '12', '16', '2025-02-20', '2026-02-20', 'Active', '9123456789'),
(29, 'KARA', '9', '15', '2024-11-11', '2025-11-11', 'Active', '09123456789');

-- --------------------------------------------------------

--
-- Table structure for table `tblpayments`
--

CREATE TABLE `tblpayments` (
  `OR_No` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `details` varchar(100) DEFAULT NULL,
  `amounts` decimal(10,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpayments`
--

INSERT INTO `tblpayments` (`OR_No`, `id`, `details`, `amounts`, `date`, `user`, `name`) VALUES
('011', 153, 'Barangay Clearance Payment', 20.00, '2024-11-13', 'admin', ' Faith S Arocha'),
('022', 154, 'Business Permit Payment', 50.00, '2024-11-13', 'admin', ' JERICBARS');

-- --------------------------------------------------------

--
-- Table structure for table `tblpermit`
--

CREATE TABLE `tblpermit` (
  `id` int(11) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `owner1` varchar(200) DEFAULT NULL,
  `owner2` varchar(80) DEFAULT NULL,
  `nature` varchar(220) DEFAULT NULL,
  `applied` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpermit`
--

INSERT INTO `tblpermit` (`id`, `name`, `owner1`, `owner2`, `nature`, `applied`) VALUES
(6, 'ETOM PAWNSHOP', 'Sherwin Etom', '', 'Tech', '2024-09-15'),
(7, 'JERICBARS', 'Sherwin Etom', 'Kier Jemera', 'Gaybar', '2024-11-13');

-- --------------------------------------------------------

--
-- Table structure for table `tblposition`
--

CREATE TABLE `tblposition` (
  `id` int(11) NOT NULL,
  `position` varchar(50) DEFAULT NULL,
  `order` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblposition`
--

INSERT INTO `tblposition` (`id`, `position`, `order`) VALUES
(4, 'Captain', 1),
(7, 'Councilor 1', 2),
(8, 'Councilor  2', 3),
(9, 'Councilor 3', 4),
(10, 'Councilor 4', 5),
(11, 'Councilor 5', 6),
(12, 'Councilor  6', 7),
(13, 'Councilor 7', 8),
(14, 'SK Chairman', 9),
(15, 'Secretary', 10),
(16, 'Treasurer', 11);

-- --------------------------------------------------------

--
-- Table structure for table `tblprecinct`
--

CREATE TABLE `tblprecinct` (
  `id` int(11) NOT NULL,
  `precinct` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblprecinct`
--

INSERT INTO `tblprecinct` (`id`, `precinct`, `details`) VALUES
(2, 'A0115', 'Purok 8-A'),
(4, 'B0116', 'Purok 6'),
(5, 'D09974', 'Purok 1-B'),
(6, 'Z3214', 'Purok 9'),
(7, 'Q0014', 'Elementary School');

-- --------------------------------------------------------

--
-- Table structure for table `tblpurok`
--

CREATE TABLE `tblpurok` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `cellphone_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpurok`
--

INSERT INTO `tblpurok` (`id`, `name`, `details`, `cellphone_number`) VALUES
(13, 'Purok 1', 'MAMUGAY, GAUDIOSA B.', '9053136585'),
(14, 'Purok 1-A', 'MANUGAS, STEVEN C.', '9352649616'),
(15, 'Purok 1-B', 'MANUGAS, MIGUELA G.', '9269519908'),
(16, 'Purok 2', 'SOLITARIO, JEL JOY C.', '9067686551'),
(17, 'Purok 3', 'DAANG, RAZELLE R.', '9358888462'),
(18, 'Purok 4', 'BARIÑAN, NEORILITA P.', '9977458983/09924154503'),
(19, 'Purok 5', 'VILLARUZ, ROWENA F.', '9057434178'),
(20, 'Purok 6', 'FLORES, JOCELYN B.', '9354641156'),
(21, 'Purok 6-A', 'PEDARSE, RIZALDE C.', '9057922996'),
(22, 'Purok 7', 'DELA CRUZ, LUZVIMINDA R.', '9756121453'),
(23, 'Purok 8', 'BUBULI, ROLANDO T.', '9365105415'),
(24, 'Purok 8-A', 'PARADERO, ESEQUIL S.', '9559352274'),
(27, 'Purok 9', 'TORRES, VICENTA G.', '9161970501'),
(28, 'Purok 10', 'ARCADIO, CESARIO A.', '9752615655'),
(29, 'Purok 10-A', 'REBUSTO, LEONILO A.', '9066722813'),
(30, 'Purok 11', 'VOSOTROS, EMILY T.', '9261730233'),
(31, 'Purok 12', 'GABOR, RAMON SR. A.', '9979803170'),
(32, 'Purok 12-A', 'NATINGA, ANNIE D.', '9368089216'),
(33, 'Purok 13', 'TACDAG, EVANGELINE B.', '9362318381'),
(34, 'Purok 14', 'MATURAN, HENRY B.', '9559727714'),
(35, 'Purok 14-A', 'FLORENTINO A. UY, JR.', '9261711106'),
(36, 'Purok 1A BEL-AIR', 'MONTEBON, GARLANDO O.', '9956974607'),
(37, 'Purok 1C MIMBALOT', 'PACQUIAO, MECHILLE C.', '9657332097'),
(38, 'Purok 1B MIMBALOT', 'DAÑO, JOSEPHINE M.', '9351019750'),
(39, 'Purok 2 MIMBALOT', 'ERMAC, CARMELITA M.', '9553388211'),
(40, 'Purok 3 MIMBALOT', 'ERSAN, ROLANDO T.', '9555837136'),
(41, 'Purok 4A MIMBALOT', 'CANILLAS, RICARDO B. JR.', '9059748936'),
(42, 'Purok 4B MIMBALOT', 'DIDATO, JOSE LOUGE C.', '9551838323'),
(43, 'Purok 5 BLISS MIMBALOT', 'CALING, CONDRADO C.', '9362364003'),
(44, 'Purok 1 TONGGO', 'CAOILE. GLORIA S.', '9158544817'),
(45, 'Purok 2 TONGGO', 'OLAYBAR, REMEDIOS Q.', '9061361424'),
(46, 'Purok 3 TONGGO', 'JOEL, OWAYAS B.', '9559276132'),
(47, 'Purok 3A ST. MICHAEL\'S HEIGHTS', 'GWEN, LOMONGO', '9457025548');

-- --------------------------------------------------------

--
-- Table structure for table `tblresident`
--

CREATE TABLE `tblresident` (
  `id` int(11) NOT NULL,
  `national_id` varchar(100) DEFAULT NULL,
  `demographic_group` varchar(50) NOT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `picture` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `middlename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `skills` varchar(20) DEFAULT NULL,
  `birthplace` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civilstatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gender` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `purok` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `voterstatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `identified_as` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `resident_type` int(11) DEFAULT 1,
  `remarks` text DEFAULT NULL,
  `precinct_number` varchar(100) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblresident`
--

INSERT INTO `tblresident` (`id`, `national_id`, `demographic_group`, `citizenship`, `picture`, `firstname`, `middlename`, `lastname`, `skills`, `birthplace`, `birthdate`, `age`, `civilstatus`, `gender`, `purok`, `voterstatus`, `identified_as`, `phone`, `email`, `occupation`, `address`, `resident_type`, `remarks`, `precinct_number`, `is_deleted`) VALUES
(189, '06', 'Senior Citizen', 'Pilipino', '15092024114117450191568_1015683769993133_4789656555843244787_n.jpg', 'Inoj', 'Q', 'Edullantes', 'Web Developer', 'Mimbalot', '1998-10-20', 26, 'Married', 'Male', 'Purok 1C MIMBALOT', 'Yes', 'Positive', '', '', '', 'ILIGAN CITY, LANAO DEL NORTE', 1, '', 'A133', 1),
(183, '01', 'PWDs', '01', '15092024103036120625174_2728860444023365_1066786861815184209_n.jpg', 'Kier', 'A', 'Libumfacil', 'Graphics Designer', 'CDO', '2000-04-03', 24, 'Widow', 'Male', 'Purok 7', 'Yes', 'Positive', '', '', '', 'BARANGAY BURU-UN PRK7 ILIGAN CITY', 1, '', 'A166', 0),
(181, '0123456789', 'ERPAT(BELA)', 'Pilipino', '15092024041325272888213_1118697002222793_4886443169141954643_n.jpg', 'Janrey', 'C', 'Paradero', 'Graphics Designer', 'Buru-un', '2001-05-23', 23, 'Single', 'Male', 'Purok 6', 'Yes', 'Positive', '09265986032', '', '', 'Purok 8-A BURU-UN ILIGAN CITY', 1, '', 'A188', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblticket_logs`
--

CREATE TABLE `tblticket_logs` (
  `id` int(11) NOT NULL,
  `ticket_number` int(11) DEFAULT NULL,
  `tracking_number` varchar(50) NOT NULL,
  `chosen_option` varchar(50) NOT NULL,
  `log_date` date NOT NULL,
  `log_time` time NOT NULL,
  `resident_id` int(1) NOT NULL,
  `priority` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(10) NOT NULL DEFAULT 'Pending',
  `is_removed` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblticket_logs`
--

INSERT INTO `tblticket_logs` (`id`, `ticket_number`, `tracking_number`, `chosen_option`, `log_date`, `log_time`, `resident_id`, `priority`, `status`, `is_removed`) VALUES
(100, 1, '0E243E181E', 'Barangay Certificate', '2024-11-17', '02:46:42', 189, 0, 'Done', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_events`
--

CREATE TABLE `tbl_events` (
  `id` int(11) NOT NULL,
  `event_date` date NOT NULL,
  `event_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_events`
--

INSERT INTO `tbl_events` (`id`, `event_date`, `event_description`) VALUES
(35, '2024-11-17', 'BDAY ETOM'),
(36, '2024-11-17', 'ETOM LOVE JERIC');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_support`
--

CREATE TABLE `tbl_support` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_support`
--

INSERT INTO `tbl_support` (`id`, `name`, `email`, `number`, `subject`, `message`, `date`) VALUES
(4, 'Janrey', 'paradero3418@gmail.com', '09265986032', 'IT BARANGAY SUPPORT', 'OPERATION & MONITORING', '2024-09-18 13:45:37');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `logged_in` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `user_type` varchar(20) DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `logged_in`, `username`, `password`, `user_type`, `avatar`, `created_at`) VALUES
(11, 1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'administrator', '15092024114415bbic1.png', '2024-10-28 12:15:42'),
(15, 0, 'Inoj', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'staff', '15092024120926bbic1.png', '2024-10-28 12:15:42'),
(17, 0, 'User1', 'b3daa77b4c04a9551b8781d03191fe098f325e67', 'staff', '03102024040911male_boy_person_people_avatar_icon_159358.png', '2024-10-28 12:15:42'),
(18, 0, 'User2', 'a1881c06eec96db9901c7bbfe41c42a3f08e9cb4', 'staff', '03102024040927male_boy_person_people_avatar_icon_159358.png', '2024-10-28 12:15:42'),
(20, 0, 'User3', '0b7f849446d3383546d15a480966084442cd2193', 'staff', '03102024041002male_boy_person_people_avatar_icon_159358.png', '2024-10-28 12:15:42'),
(21, 0, 'User4', '06e6eef6adf2e5f54ea6c43c376d6d36605f810e', 'staff', '03102024041018girlicon.png', '2024-10-28 12:15:42'),
(22, 0, 'User5', '7d112681b8dd80723871a87ff506286613fa9cf6', 'staff', '03102024041034girlicon.png', '2024-10-28 12:15:42'),
(23, 0, 'User6', '312a46dc52117efa4e3096eda510370f01c83b27', 'staff', '03102024041047girlicon.png', '2024-10-28 12:15:42'),
(24, 0, 'Janrey', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'administrator', '03102024041124iligan.png', '2024-10-28 12:15:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblbrgy_info`
--
ALTER TABLE `tblbrgy_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblchairmanship`
--
ALTER TABLE `tblchairmanship`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblofficials`
--
ALTER TABLE `tblofficials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpayments`
--
ALTER TABLE `tblpayments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpermit`
--
ALTER TABLE `tblpermit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblposition`
--
ALTER TABLE `tblposition`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblprecinct`
--
ALTER TABLE `tblprecinct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpurok`
--
ALTER TABLE `tblpurok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblresident`
--
ALTER TABLE `tblresident`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblticket_logs`
--
ALTER TABLE `tblticket_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_events`
--
ALTER TABLE `tbl_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_support`
--
ALTER TABLE `tbl_support`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblbrgy_info`
--
ALTER TABLE `tblbrgy_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblchairmanship`
--
ALTER TABLE `tblchairmanship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblofficials`
--
ALTER TABLE `tblofficials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tblpayments`
--
ALTER TABLE `tblpayments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;

--
-- AUTO_INCREMENT for table `tblpermit`
--
ALTER TABLE `tblpermit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblposition`
--
ALTER TABLE `tblposition`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblprecinct`
--
ALTER TABLE `tblprecinct`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblpurok`
--
ALTER TABLE `tblpurok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `tblresident`
--
ALTER TABLE `tblresident`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `tblticket_logs`
--
ALTER TABLE `tblticket_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `tbl_events`
--
ALTER TABLE `tbl_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_support`
--
ALTER TABLE `tbl_support`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
