<?php
include '../server/server.php'; // Database connection

session_start(); // Start session if not already started

if (isset($_SESSION['id'])) {
    // Update the logged_in status to 0 (logged out)
    $userId = $_SESSION['id'];
    $updateQuery = "UPDATE tbl_users SET logged_in = 0 WHERE id = '$userId'";
    $conn->query($updateQuery);
}

// Destroy session and unset session variables
session_destroy();
unset($_SESSION['username']);
unset($_SESSION['role']);

// Start a new session to set the logout message
session_start();
$_SESSION['message'] = "You have been logged out!";
$_SESSION['success'] = 'danger';

// Redirect to login page
header('Location: ../login.php?clearStorage=true');
exit();
?>
