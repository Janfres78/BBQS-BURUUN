<?php 
    include '../server/server.php';

    if(!isset($_SESSION['username']) && $_SESSION['role'] != 'administrator'){
        if (isset($_SERVER["HTTP_REFERER"])) {
            header("Location: " . $_SERVER["HTTP_REFERER"]);
        }
    }

    // Sanitize the incoming ID parameter
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
    
        // Update the is_deleted flag instead of deleting the record
        $query = "UPDATE tblresident SET is_deleted = 1 WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        
        // Execute the query and check if it was successful
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Resident has been marked as deleted!';
            $_SESSION['success'] = 'success'; 
        } else {
            $_SESSION['message'] = 'Database error: ' . $conn->error;
            $_SESSION['success'] = 'danger';
        }
    } else {
        $_SESSION['message'] = 'Missing Resident ID!';
        $_SESSION['success'] = 'danger';
    }

    // Redirect to the residents page
    header("Location: ../resident.php");
    $conn->close();
?>
