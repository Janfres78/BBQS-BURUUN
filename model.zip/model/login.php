<?php 
include '../server/server.php';

$username  = $conn->real_escape_string($_POST['username']);
$password  = sha1($conn->real_escape_string($_POST['password']));

if ($username != '' && $password != '') {
    // Check if user exists with given username and password
    $query = "SELECT * FROM tbl_users WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Check if the user is already logged in
        if ($row['logged_in'] == 1) {
            $_SESSION['message'] = 'This user is already logged in from another device';
            $_SESSION['success'] = 'danger';
            header('location: ../login.php');
            exit();
        }

        // Log the user in and update their logged_in status
        $_SESSION['id'] = $row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['role'] = $row['user_type'];
        $_SESSION['avatar'] = $row['avatar'];

        // Update logged_in and session_timeout
        $updateQuery = "UPDATE tbl_users SET logged_in = 1, session_timeout = NOW() WHERE id = '{$row['id']}'";
        $conn->query($updateQuery);

    // Set logged_in to true (1)
    $updateQuery = "UPDATE tbl_users SET logged_in = 1 WHERE id = '{$row['id']}'";
    $conn->query($updateQuery);

    $_SESSION['message'] = 'You have successfully logged in to the Barangay Buru-un Queueing System!';
    $_SESSION['success'] = 'success';
    header('Location: ../dashboard.php?setStorage=true');
    exit();
    
    } else {
        $_SESSION['message'] = 'Username or password is incorrect!';
        $_SESSION['success'] = 'danger';
        header('location: ../login.php');
    }
} else {
    $_SESSION['message'] = 'Username or password is empty!';
    $_SESSION['success'] = 'danger';
    header('location: ../login.php');
}

// Close the database connection
$conn->close();
?>

