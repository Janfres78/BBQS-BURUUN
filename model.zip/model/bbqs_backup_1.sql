# bbqs : MySQL database backup
#
# Generated: Sunday 17. November 2024
# Hostname: localhost
# Database: bbqs
# --------------------------------------------------------


#
# Delete any existing table `tbl_events`
#

DROP TABLE IF EXISTS `tbl_events`;


#
# Table structure of table `tbl_events`
#



CREATE TABLE `tbl_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_date` date NOT NULL,
  `event_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tbl_events VALUES("35","2024-11-17","BDAY ETOM");
INSERT INTO tbl_events VALUES("36","2024-11-17","ETOM LOVE JERIC");



#
# Delete any existing table `tbl_support`
#

DROP TABLE IF EXISTS `tbl_support`;


#
# Table structure of table `tbl_support`
#



CREATE TABLE `tbl_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tbl_support VALUES("4","Janrey","paradero3418@gmail.com","09265986032","IT BARANGAY SUPPORT","OPERATION & MONITORING","2024-09-18 21:45:37");



#
# Delete any existing table `tbl_users`
#

DROP TABLE IF EXISTS `tbl_users`;


#
# Table structure of table `tbl_users`
#



CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logged_in` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `user_type` varchar(20) DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tbl_users VALUES("11","1","admin","d033e22ae348aeb5660fc2140aec35850c4da997","administrator","15092024114415bbic1.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("15","0","Inoj","7c4a8d09ca3762af61e59520943dc26494f8941b","staff","15092024120926bbic1.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("17","0","User1","b3daa77b4c04a9551b8781d03191fe098f325e67","staff","03102024040911male_boy_person_people_avatar_icon_159358.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("18","0","User2","a1881c06eec96db9901c7bbfe41c42a3f08e9cb4","staff","03102024040927male_boy_person_people_avatar_icon_159358.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("20","0","User3","0b7f849446d3383546d15a480966084442cd2193","staff","03102024041002male_boy_person_people_avatar_icon_159358.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("21","0","User4","06e6eef6adf2e5f54ea6c43c376d6d36605f810e","staff","03102024041018girlicon.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("22","0","User5","7d112681b8dd80723871a87ff506286613fa9cf6","staff","03102024041034girlicon.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("23","0","User6","312a46dc52117efa4e3096eda510370f01c83b27","staff","03102024041047girlicon.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("24","0","Janrey","f7c3bc1d808e04732adf679965ccc34ca7ae3441","administrator","03102024041124iligan.png","2024-10-28 20:15:42");



#
# Delete any existing table `tblbrgy_info`
#

DROP TABLE IF EXISTS `tblbrgy_info`;


#
# Table structure of table `tblbrgy_info`
#



CREATE TABLE `tblbrgy_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `province` varchar(100) DEFAULT NULL,
  `town` varchar(100) DEFAULT NULL,
  `brgy_name` varchar(50) DEFAULT NULL,
  `number` varchar(50) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `city_logo` varchar(100) DEFAULT NULL,
  `brgy_logo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblbrgy_info VALUES("1","Lanao del Norte ","Iligan City","Barangay Buru-un","09265986032","Buru-un  is a barangay of Iligan City in the province of Lanao del Norte within Region 10 (Northern Mindanao), Philippines.","15092024035002BB123.png","15092024035002iligan.png","15092024035002bbic1.png");



#
# Delete any existing table `tblchairmanship`
#

DROP TABLE IF EXISTS `tblchairmanship`;


#
# Table structure of table `tblchairmanship`
#



CREATE TABLE `tblchairmanship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblchairmanship VALUES("5","Committee on Health");
INSERT INTO tblchairmanship VALUES("6","Committee on Education");
INSERT INTO tblchairmanship VALUES("7","Committee on Rules");
INSERT INTO tblchairmanship VALUES("8","Committee on Infra");
INSERT INTO tblchairmanship VALUES("9","Committee on Solid Waste");
INSERT INTO tblchairmanship VALUES("10","Committee on Sports");
INSERT INTO tblchairmanship VALUES("12","No Chairmanship");



#
# Delete any existing table `tblofficials`
#

DROP TABLE IF EXISTS `tblofficials`;


#
# Table structure of table `tblofficials`
#



CREATE TABLE `tblofficials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `chairmanship` varchar(50) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `termstart` date DEFAULT NULL,
  `termend` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `contact_number` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblofficials VALUES("4","Brad Enoy","11","7","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("5","TATA CALLENO","11","8","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("6","ALAN BARINQUE","11","9","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("7","JAN NIKKO GERASTA","11","10","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("11","KARL LACIDA","11","14","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("14","MARIANITA B. PARADELA","2","4","2024-09-15","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("17","MARIANITA B. PARADELA","12","4","2024-09-01","2025-12-31","Active"," 912 345 6789");
INSERT INTO tblofficials VALUES("18","ALAN BARINQUE","12","7","2024-09-01","2025-12-31","Active","917 234 5678");
INSERT INTO tblofficials VALUES("19","TATA CALLENO","12","8","2024-09-01","2025-12-31","Active","927 456 7890");
INSERT INTO tblofficials VALUES("20","Brad Enoy","12","9","2024-09-01","2025-12-31","Inactive","939 876 5432");
INSERT INTO tblofficials VALUES("21","KARL LACIDA","12","14","2024-09-01","2025-12-31","Active","998 765 4321");
INSERT INTO tblofficials VALUES("24","Janrey","12","16","2025-02-20","2026-02-20","Active","9123456789");
INSERT INTO tblofficials VALUES("29","KARA","9","15","2024-11-11","2025-11-11","Active","09123456789");



#
# Delete any existing table `tblpayments`
#

DROP TABLE IF EXISTS `tblpayments`;


#
# Table structure of table `tblpayments`
#



CREATE TABLE `tblpayments` (
  `OR_No` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `details` varchar(100) DEFAULT NULL,
  `amounts` decimal(10,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblpayments VALUES("011","153","Barangay Clearance Payment","20.00","2024-11-13","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("022","154","Business Permit Payment","50.00","2024-11-13","admin"," JERICBARS");



#
# Delete any existing table `tblpermit`
#

DROP TABLE IF EXISTS `tblpermit`;


#
# Table structure of table `tblpermit`
#



CREATE TABLE `tblpermit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `owner1` varchar(200) DEFAULT NULL,
  `owner2` varchar(80) DEFAULT NULL,
  `nature` varchar(220) DEFAULT NULL,
  `applied` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblpermit VALUES("6","ETOM PAWNSHOP","Sherwin Etom","","Tech","2024-09-15");
INSERT INTO tblpermit VALUES("7","JERICBARS","Sherwin Etom","Kier Jemera","Gaybar","2024-11-13");



#
# Delete any existing table `tblposition`
#

DROP TABLE IF EXISTS `tblposition`;


#
# Table structure of table `tblposition`
#



CREATE TABLE `tblposition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` varchar(50) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblposition VALUES("4","Captain","1");
INSERT INTO tblposition VALUES("7","Councilor 1","2");
INSERT INTO tblposition VALUES("8","Councilor  2","3");
INSERT INTO tblposition VALUES("9","Councilor 3","4");
INSERT INTO tblposition VALUES("10","Councilor 4","5");
INSERT INTO tblposition VALUES("11","Councilor 5","6");
INSERT INTO tblposition VALUES("12","Councilor  6","7");
INSERT INTO tblposition VALUES("13","Councilor 7","8");
INSERT INTO tblposition VALUES("14","SK Chairman","9");
INSERT INTO tblposition VALUES("15","Secretary","10");
INSERT INTO tblposition VALUES("16","Treasurer","11");



#
# Delete any existing table `tblprecinct`
#

DROP TABLE IF EXISTS `tblprecinct`;


#
# Table structure of table `tblprecinct`
#



CREATE TABLE `tblprecinct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `precinct` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblprecinct VALUES("2","A0115","Purok 8-A");
INSERT INTO tblprecinct VALUES("4","B0116","Purok 6");
INSERT INTO tblprecinct VALUES("5","D09974","Purok 1-B");
INSERT INTO tblprecinct VALUES("6","Z3214","Purok 9");
INSERT INTO tblprecinct VALUES("7","Q0014","Elementary School");



#
# Delete any existing table `tblpurok`
#

DROP TABLE IF EXISTS `tblpurok`;


#
# Table structure of table `tblpurok`
#



CREATE TABLE `tblpurok` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `cellphone_number` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblpurok VALUES("13","Purok 1","MAMUGAY, GAUDIOSA B.","9053136585");
INSERT INTO tblpurok VALUES("14","Purok 1-A","MANUGAS, STEVEN C.","9352649616");
INSERT INTO tblpurok VALUES("15","Purok 1-B","MANUGAS, MIGUELA G.","9269519908");
INSERT INTO tblpurok VALUES("16","Purok 2","SOLITARIO, JEL JOY C.","9067686551");
INSERT INTO tblpurok VALUES("17","Purok 3","DAANG, RAZELLE R.","9358888462");
INSERT INTO tblpurok VALUES("18","Purok 4","BARIÑAN, NEORILITA P.","9977458983/09924154503");
INSERT INTO tblpurok VALUES("19","Purok 5","VILLARUZ, ROWENA F.","9057434178");
INSERT INTO tblpurok VALUES("20","Purok 6","FLORES, JOCELYN B.","9354641156");
INSERT INTO tblpurok VALUES("21","Purok 6-A","PEDARSE, RIZALDE C.","9057922996");
INSERT INTO tblpurok VALUES("22","Purok 7","DELA CRUZ, LUZVIMINDA R.","9756121453");
INSERT INTO tblpurok VALUES("23","Purok 8","BUBULI, ROLANDO T.","9365105415");
INSERT INTO tblpurok VALUES("24","Purok 8-A","PARADERO, ESEQUIL S.","9559352274");
INSERT INTO tblpurok VALUES("27","Purok 9","TORRES, VICENTA G.","9161970501");
INSERT INTO tblpurok VALUES("28","Purok 10","ARCADIO, CESARIO A.","9752615655");
INSERT INTO tblpurok VALUES("29","Purok 10-A","REBUSTO, LEONILO A.","9066722813");
INSERT INTO tblpurok VALUES("30","Purok 11","VOSOTROS, EMILY T.","9261730233");
INSERT INTO tblpurok VALUES("31","Purok 12","GABOR, RAMON SR. A.","9979803170");
INSERT INTO tblpurok VALUES("32","Purok 12-A","NATINGA, ANNIE D.","9368089216");
INSERT INTO tblpurok VALUES("33","Purok 13","TACDAG, EVANGELINE B.","9362318381");
INSERT INTO tblpurok VALUES("34","Purok 14","MATURAN, HENRY B.","9559727714");
INSERT INTO tblpurok VALUES("35","Purok 14-A","FLORENTINO A. UY, JR.","9261711106");
INSERT INTO tblpurok VALUES("36","Purok 1A BEL-AIR","MONTEBON, GARLANDO O.","9956974607");
INSERT INTO tblpurok VALUES("37","Purok 1C MIMBALOT","PACQUIAO, MECHILLE C.","9657332097");
INSERT INTO tblpurok VALUES("38","Purok 1B MIMBALOT","DAÑO, JOSEPHINE M.","9351019750");
INSERT INTO tblpurok VALUES("39","Purok 2 MIMBALOT","ERMAC, CARMELITA M.","9553388211");
INSERT INTO tblpurok VALUES("40","Purok 3 MIMBALOT","ERSAN, ROLANDO T.","9555837136");
INSERT INTO tblpurok VALUES("41","Purok 4A MIMBALOT","CANILLAS, RICARDO B. JR.","9059748936");
INSERT INTO tblpurok VALUES("42","Purok 4B MIMBALOT","DIDATO, JOSE LOUGE C.","9551838323");
INSERT INTO tblpurok VALUES("43","Purok 5 BLISS MIMBALOT","CALING, CONDRADO C.","9362364003");
INSERT INTO tblpurok VALUES("44","Purok 1 TONGGO","CAOILE. GLORIA S.","9158544817");
INSERT INTO tblpurok VALUES("45","Purok 2 TONGGO","OLAYBAR, REMEDIOS Q.","9061361424");
INSERT INTO tblpurok VALUES("46","Purok 3 TONGGO","JOEL, OWAYAS B.","9559276132");
INSERT INTO tblpurok VALUES("47","Purok 3A ST. MICHAEL'S HEIGHTS","GWEN, LOMONGO","9457025548");



#
# Delete any existing table `tblresident`
#

DROP TABLE IF EXISTS `tblresident`;


#
# Table structure of table `tblresident`
#



CREATE TABLE `tblresident` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(100) DEFAULT NULL,
  `demographic_group` varchar(50) NOT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `picture` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `middlename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `skills` varchar(20) DEFAULT NULL,
  `birthplace` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civilstatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gender` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `purok` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `voterstatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `identified_as` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `resident_type` int(11) DEFAULT 1,
  `remarks` text DEFAULT NULL,
  `precinct_number` varchar(100) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=201 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO tblresident VALUES("189","06","Senior Citizen","Pilipino","15092024114117450191568_1015683769993133_4789656555843244787_n.jpg","Inoj","Q","Edullantes","Web Developer","Mimbalot","1998-10-20","26","Married","Male","Purok 1C MIMBALOT","Yes","Positive","","","","ILIGAN CITY, LANAO DEL NORTE","1","","A133","1");
INSERT INTO tblresident VALUES("183","01","PWDs","01","15092024103036120625174_2728860444023365_1066786861815184209_n.jpg","Kier","A","Libumfacil","Graphics Designer","CDO","2000-04-03","24","Widow","Male","Purok 7","Yes","Positive","","","","BARANGAY BURU-UN PRK7 ILIGAN CITY","1","","A166","0");
INSERT INTO tblresident VALUES("181","0123456789","ERPAT(BELA)","Pilipino","15092024041325272888213_1118697002222793_4886443169141954643_n.jpg","Janrey","C","Paradero","Graphics Designer","Buru-un","2001-05-23","23","Single","Male","Purok 6","Yes","Positive","09265986032","","","Purok 8-A BURU-UN ILIGAN CITY","1","","A188","0");



#
# Delete any existing table `tblticket_logs`
#

DROP TABLE IF EXISTS `tblticket_logs`;


#
# Table structure of table `tblticket_logs`
#



CREATE TABLE `tblticket_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_number` int(11) DEFAULT NULL,
  `tracking_number` varchar(50) NOT NULL,
  `chosen_option` varchar(50) NOT NULL,
  `log_date` date NOT NULL,
  `log_time` time NOT NULL,
  `resident_id` int(1) NOT NULL,
  `priority` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(10) NOT NULL DEFAULT 'Pending',
  `is_removed` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblticket_logs VALUES("100","1","0E243E181E","Barangay Certificate","2024-11-17","02:46:42","189","0","Done","1");

