<?php 
	include '../server/server.php';

	if(!isset($_SESSION['username'])){
		if (isset($_SERVER["HTTP_REFERER"])) {
			header("Location: " . $_SERVER["HTTP_REFERER"]);
		}
	}
	
    $id 	= $conn->real_escape_string($_POST['id']);
	$national_id 	= $conn->real_escape_string($_POST['national']); 
	$fname 	= $conn->real_escape_string($_POST['fname']);
	$mname 	= $conn->real_escape_string($_POST['mname']);
    $lname 	= $conn->real_escape_string($_POST['lname']);
	$skills = $conn->real_escape_string($_POST['skills']);
	$precinct_number = $conn->real_escape_string($_POST['precinct_number']);
    $bplace = $conn->real_escape_string($_POST['bplace']);
	$bdate 	= $conn->real_escape_string($_POST['bdate']);
    $age 	= $conn->real_escape_string($_POST['age']);
	$category = $conn->real_escape_string($_POST['category']); 
    $cstatus = $conn->real_escape_string($_POST['cstatus']);
	$gender = $conn->real_escape_string($_POST['gender']);
    $purok 	= $conn->real_escape_string($_POST['purok']);
	$vstatus = $conn->real_escape_string($_POST['vstatus']);
    $indetity = $conn->real_escape_string($_POST['indetity']);
    $email 	= $conn->real_escape_string($_POST['email']);
	$number = $conn->real_escape_string($_POST['number']);
    $address = $conn->real_escape_string($_POST['address']);
	$occu 	= $conn->real_escape_string($_POST['occupation']);
    $citi 	= $conn->real_escape_string($_POST['citizenship']);
	$deceased = $conn->real_escape_string($_POST['deceased']);
    $remarks = $conn->real_escape_string($_POST['remarks']);
	$profile = $conn->real_escape_string($_POST['profileimg']); // base 64 image
	$profile2 = $_FILES['img']['name'];

	// Change profile2 name
	$newName = date('dmYHis').str_replace(" ", "", $profile2);

	// Image file directory
  	$target = "../assets/uploads/resident_profile/".basename($newName);

	// Check if National ID is already taken by another resident
	$check = "SELECT id FROM tblresident WHERE national_id='$national_id' AND id != '$id'";
	$nat = $conn->query($check);

	if ($nat->num_rows == 0) {  // If no other resident has this National ID
		if (!empty($id)) {

			// Handling different profile update conditions
			if (!empty($profile) && !empty($profile2)) {
				$query = "UPDATE tblresident SET national_id='$national_id', citizenship='$citi', picture='$profile', 
			    firstname='$fname', middlename='$mname', lastname='$lname', skills='$skills', precinct_number='$precinct_number', birthplace='$bplace',
			    birthdate='$bdate', age=$age, demographic_group='$category', civilstatus='$cstatus', 
				gender='$gender', purok='$purok', voterstatus='$vstatus', identified_as='$indetity', 
				phone='$number', email='$email', occupation='$occu', address='$address', 
				resident_type='$deceased', remarks='$remarks' WHERE id=$id;";

				if ($conn->query($query) === true) {
					$_SESSION['message'] = 'Resident Information has been updated!';
					$_SESSION['success'] = 'success';
				}

			} else if (!empty($profile) && empty($profile2)) {
				$query = "UPDATE tblresident SET national_id='$national_id', citizenship='$citi', picture='$profile', 
				firstname='$fname', middlename='$mname', lastname='$lname', skills='$skills', precinct_number='$precinct_number', birthplace='$bplace', 
				birthdate='$bdate', age=$age, demographic_group='$category', civilstatus='$cstatus', 
				gender='$gender', purok='$purok', voterstatus='$vstatus', identified_as='$indetity', 
				phone='$number', email='$email', occupation='$occu', address='$address', 
				resident_type='$deceased', remarks='$remarks' WHERE id=$id;";
				
				if ($conn->query($query) === true) {
					$_SESSION['message'] = 'Resident Information has been updated!';
					$_SESSION['success'] = 'success';
				}

			} else if (empty($profile) && !empty($profile2)) {
				$query = "UPDATE tblresident SET national_id='$national_id', citizenship='$citi', picture='$newName', 
				firstname='$fname', middlename='$mname', lastname='$lname', skills='$skills', precinct_number='$precinct_number', birthplace='$bplace', 
				birthdate='$bdate', age=$age, demographic_group='$category', civilstatus='$cstatus', 
				gender='$gender', purok='$purok', voterstatus='$vstatus', identified_as='$indetity', 
				phone='$number', email='$email', occupation='$occu', address='$address', 
				resident_type='$deceased', remarks='$remarks' WHERE id=$id;";
				
				if ($conn->query($query) === true) {
					$_SESSION['message'] = 'Resident Information has been updated!';

					if (move_uploaded_file($_FILES['img']['tmp_name'], $target)) {
						$_SESSION['message'] = 'Resident Information has been updated!';
						$_SESSION['success'] = 'success';
					}
				}

			} else {
				$query = "UPDATE tblresident SET national_id='$national_id', citizenship='$citi', 
				firstname='$fname', middlename='$mname', lastname='$lname', skills='$skills', precinct_number='$precinct_number', birthplace='$bplace', 
				birthdate='$bdate', age=$age, demographic_group='$category', civilstatus='$cstatus', 
				gender='$gender', purok='$purok', voterstatus='$vstatus', identified_as='$indetity', 
				phone='$number', email='$email', occupation='$occu', address='$address', 
				resident_type='$deceased', remarks='$remarks' WHERE id=$id;";
				
				if ($conn->query($query) === true) {
					$_SESSION['message'] = 'Resident Information has been updated!';
					$_SESSION['success'] = 'success';
				}
			}

		} else {
			$_SESSION['message'] = 'Please complete the form!';
			$_SESSION['success'] = 'danger';
		}
	} else {
		$_SESSION['message'] = 'National ID is already taken by another resident. Please enter a unique National ID!';
		$_SESSION['success'] = 'danger';
	}

	header("Location: ../resident.php");
	$conn->close();
?>  
