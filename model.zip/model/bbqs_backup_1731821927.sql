# bbqs : MySQL database backup
#
# Generated: Sunday 17. November 2024
# Hostname: localhost
# Database: bbqs
# --------------------------------------------------------


#
# Delete any existing table `tbl_events`
#

DROP TABLE IF EXISTS `tbl_events`;


#
# Table structure of table `tbl_events`
#



CREATE TABLE `tbl_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_date` date NOT NULL,
  `event_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tbl_events VALUES("15","2024-10-14","EXAM");
INSERT INTO tbl_events VALUES("16","2024-10-14"," JERIC BDAY");
INSERT INTO tbl_events VALUES("17","2024-10-14"," EXAM MIDTERM");
INSERT INTO tbl_events VALUES("18","2024-10-15","EXAM");
INSERT INTO tbl_events VALUES("19","2024-10-16","EXAM");
INSERT INTO tbl_events VALUES("20","2024-10-14","EXAM, JERIC BDAY, EXAM MIDTERM, BDAYY");
INSERT INTO tbl_events VALUES("21","2024-10-14","");
INSERT INTO tbl_events VALUES("22","2024-10-14","");
INSERT INTO tbl_events VALUES("23","2024-10-15"," JANREY BDAY");
INSERT INTO tbl_events VALUES("24","2024-10-15","");
INSERT INTO tbl_events VALUES("25","2024-11-04","Jan");
INSERT INTO tbl_events VALUES("26","2024-11-04"," janjan");
INSERT INTO tbl_events VALUES("27","2024-11-09","jandsaf");
INSERT INTO tbl_events VALUES("28","2024-11-09","bday jeric");
INSERT INTO tbl_events VALUES("29","2024-11-09","");
INSERT INTO tbl_events VALUES("30","2024-11-18","dvd");
INSERT INTO tbl_events VALUES("31","2024-11-18","dfdfdf");
INSERT INTO tbl_events VALUES("32","2024-11-20","");
INSERT INTO tbl_events VALUES("33","2024-12-17","jan");
INSERT INTO tbl_events VALUES("34","2024-12-17","dada");



#
# Delete any existing table `tbl_support`
#

DROP TABLE IF EXISTS `tbl_support`;


#
# Table structure of table `tbl_support`
#



CREATE TABLE `tbl_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tbl_support VALUES("4","Janrey","paradero3418@gmail.com","09265986032","IT BARANGAY SUPPORT","OPERATION & MONITORING","2024-09-18 21:45:37");



#
# Delete any existing table `tbl_users`
#

DROP TABLE IF EXISTS `tbl_users`;


#
# Table structure of table `tbl_users`
#



CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logged_in` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `user_type` varchar(20) DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tbl_users VALUES("11","1","admin","d033e22ae348aeb5660fc2140aec35850c4da997","administrator","15092024114415bbic1.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("15","0","Inoj","7c4a8d09ca3762af61e59520943dc26494f8941b","staff","15092024120926bbic1.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("17","0","User1","b3daa77b4c04a9551b8781d03191fe098f325e67","staff","03102024040911male_boy_person_people_avatar_icon_159358.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("18","0","User2","a1881c06eec96db9901c7bbfe41c42a3f08e9cb4","staff","03102024040927male_boy_person_people_avatar_icon_159358.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("20","0","User3","0b7f849446d3383546d15a480966084442cd2193","staff","03102024041002male_boy_person_people_avatar_icon_159358.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("21","0","User4","06e6eef6adf2e5f54ea6c43c376d6d36605f810e","staff","03102024041018girlicon.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("22","0","User5","7d112681b8dd80723871a87ff506286613fa9cf6","staff","03102024041034girlicon.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("23","0","User6","312a46dc52117efa4e3096eda510370f01c83b27","staff","03102024041047girlicon.png","2024-10-28 20:15:42");
INSERT INTO tbl_users VALUES("24","0","Janrey","f7c3bc1d808e04732adf679965ccc34ca7ae3441","administrator","03102024041124iligan.png","2024-10-28 20:15:42");



#
# Delete any existing table `tblbrgy_info`
#

DROP TABLE IF EXISTS `tblbrgy_info`;


#
# Table structure of table `tblbrgy_info`
#



CREATE TABLE `tblbrgy_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `province` varchar(100) DEFAULT NULL,
  `town` varchar(100) DEFAULT NULL,
  `brgy_name` varchar(50) DEFAULT NULL,
  `number` varchar(50) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `city_logo` varchar(100) DEFAULT NULL,
  `brgy_logo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblbrgy_info VALUES("1","Lanao del Norte ","Iligan City","Barangay Buru-un","09265986032","Buru-un  is a barangay of Iligan City in the province of Lanao del Norte within Region 10 (Northern Mindanao), Philippines.","15092024035002BB123.png","15092024035002iligan.png","15092024035002bbic1.png");



#
# Delete any existing table `tblchairmanship`
#

DROP TABLE IF EXISTS `tblchairmanship`;


#
# Table structure of table `tblchairmanship`
#



CREATE TABLE `tblchairmanship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblchairmanship VALUES("5","Committee on Health");
INSERT INTO tblchairmanship VALUES("6","Committee on Education");
INSERT INTO tblchairmanship VALUES("7","Committee on Rules");
INSERT INTO tblchairmanship VALUES("8","Committee on Infra");
INSERT INTO tblchairmanship VALUES("9","Committee on Solid Waste");
INSERT INTO tblchairmanship VALUES("10","Committee on Sports");
INSERT INTO tblchairmanship VALUES("12","No Chairmanship");



#
# Delete any existing table `tblofficials`
#

DROP TABLE IF EXISTS `tblofficials`;


#
# Table structure of table `tblofficials`
#



CREATE TABLE `tblofficials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `chairmanship` varchar(50) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `termstart` date DEFAULT NULL,
  `termend` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `contact_number` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblofficials VALUES("4","Brad Enoy","11","7","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("5","TATA CALLENO","11","8","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("6","ALAN BARINQUE","11","9","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("7","JAN NIKKO GERASTA","11","10","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("11","KARL LACIDA","11","14","2021-04-03","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("14","MARIANITA B. PARADELA","2","4","2024-09-15","2025-12-31","Active","0");
INSERT INTO tblofficials VALUES("17","MARIANITA B. PARADELA","12","4","2024-09-01","2025-12-31","Active"," 912 345 6789");
INSERT INTO tblofficials VALUES("18","ALAN BARINQUE","12","7","2024-09-01","2025-12-31","Active","917 234 5678");
INSERT INTO tblofficials VALUES("19","TATA CALLENO","12","8","2024-09-01","2025-12-31","Active","927 456 7890");
INSERT INTO tblofficials VALUES("20","Brad Enoy","12","9","2024-09-01","2025-12-31","Inactive","939 876 5432");
INSERT INTO tblofficials VALUES("21","KARL LACIDA","12","14","2024-09-01","2025-12-31","Active","998 765 4321");
INSERT INTO tblofficials VALUES("24","Janrey","12","16","2025-02-20","2026-02-20","Active","9123456789");



#
# Delete any existing table `tblpayments`
#

DROP TABLE IF EXISTS `tblpayments`;


#
# Table structure of table `tblpayments`
#



CREATE TABLE `tblpayments` (
  `OR_No` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `details` varchar(100) DEFAULT NULL,
  `amounts` decimal(10,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblpayments VALUES("011","153","Barangay Clearance Payment","20.00","2024-11-13","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("022","154","Business Permit Payment","50.00","2024-11-13","admin"," JERICBARS");



#
# Delete any existing table `tblpermit`
#

DROP TABLE IF EXISTS `tblpermit`;


#
# Table structure of table `tblpermit`
#



CREATE TABLE `tblpermit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `owner1` varchar(200) DEFAULT NULL,
  `owner2` varchar(80) DEFAULT NULL,
  `nature` varchar(220) DEFAULT NULL,
  `applied` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblpermit VALUES("6","ETOM PAWNSHOP","Sherwin Etom","","Tech","2024-09-15");
INSERT INTO tblpermit VALUES("7","JERICBARS","Sherwin Etom","Kier Jemera","Gaybar","2024-11-13");



#
# Delete any existing table `tblposition`
#

DROP TABLE IF EXISTS `tblposition`;


#
# Table structure of table `tblposition`
#



CREATE TABLE `tblposition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` varchar(50) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblposition VALUES("4","Captain","1");
INSERT INTO tblposition VALUES("7","Councilor 1","2");
INSERT INTO tblposition VALUES("8","Councilor  2","3");
INSERT INTO tblposition VALUES("9","Councilor 3","4");
INSERT INTO tblposition VALUES("10","Councilor 4","5");
INSERT INTO tblposition VALUES("11","Councilor 5","6");
INSERT INTO tblposition VALUES("12","Councilor  6","7");
INSERT INTO tblposition VALUES("13","Councilor 7","8");
INSERT INTO tblposition VALUES("14","SK Chairman","9");
INSERT INTO tblposition VALUES("15","Secretary","10");
INSERT INTO tblposition VALUES("16","Treasurer","11");



#
# Delete any existing table `tblprecinct`
#

DROP TABLE IF EXISTS `tblprecinct`;


#
# Table structure of table `tblprecinct`
#



CREATE TABLE `tblprecinct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `precinct` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblprecinct VALUES("2","A0115","Purok 8-A");
INSERT INTO tblprecinct VALUES("4","B0116","Purok 6");
INSERT INTO tblprecinct VALUES("5","D09974","Purok 1-B");
INSERT INTO tblprecinct VALUES("6","Z3214","Purok 9");
INSERT INTO tblprecinct VALUES("7","Q0014","Elementary School");



#
# Delete any existing table `tblpurok`
#

DROP TABLE IF EXISTS `tblpurok`;


#
# Table structure of table `tblpurok`
#



CREATE TABLE `tblpurok` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `cellphone_number` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblpurok VALUES("13","Purok 1","MAMUGAY, GAUDIOSA B.","9053136585");
INSERT INTO tblpurok VALUES("14","Purok 1-A","MANUGAS, STEVEN C.","9352649616");
INSERT INTO tblpurok VALUES("15","Purok 1-B","MANUGAS, MIGUELA G.","9269519908");
INSERT INTO tblpurok VALUES("16","Purok 2","SOLITARIO, JEL JOY C.","9067686551");
INSERT INTO tblpurok VALUES("17","Purok 3","DAANG, RAZELLE R.","9358888462");
INSERT INTO tblpurok VALUES("18","Purok 4","BARIÑAN, NEORILITA P.","9977458983/09924154503");
INSERT INTO tblpurok VALUES("19","Purok 5","VILLARUZ, ROWENA F.","9057434178");
INSERT INTO tblpurok VALUES("20","Purok 6","FLORES, JOCELYN B.","9354641156");
INSERT INTO tblpurok VALUES("21","Purok 6-A","PEDARSE, RIZALDE C.","9057922996");
INSERT INTO tblpurok VALUES("22","Purok 7","DELA CRUZ, LUZVIMINDA R.","9756121453");
INSERT INTO tblpurok VALUES("23","Purok 8","BUBULI, ROLANDO T.","9365105415");
INSERT INTO tblpurok VALUES("24","Purok 8-A","PARADERO, ESEQUIL S.","9559352274");
INSERT INTO tblpurok VALUES("27","Purok 9","TORRES, VICENTA G.","9161970501");
INSERT INTO tblpurok VALUES("28","Purok 10","ARCADIO, CESARIO A.","9752615655");
INSERT INTO tblpurok VALUES("29","Purok 10-A","REBUSTO, LEONILO A.","9066722813");
INSERT INTO tblpurok VALUES("30","Purok 11","VOSOTROS, EMILY T.","9261730233");
INSERT INTO tblpurok VALUES("31","Purok 12","GABOR, RAMON SR. A.","9979803170");
INSERT INTO tblpurok VALUES("32","Purok 12-A","NATINGA, ANNIE D.","9368089216");
INSERT INTO tblpurok VALUES("33","Purok 13","TACDAG, EVANGELINE B.","9362318381");
INSERT INTO tblpurok VALUES("34","Purok 14","MATURAN, HENRY B.","9559727714");
INSERT INTO tblpurok VALUES("35","Purok 14-A","FLORENTINO A. UY, JR.","9261711106");
INSERT INTO tblpurok VALUES("36","Purok 1A BEL-AIR","MONTEBON, GARLANDO O.","9956974607");
INSERT INTO tblpurok VALUES("37","Purok 1C MIMBALOT","PACQUIAO, MECHILLE C.","9657332097");
INSERT INTO tblpurok VALUES("38","Purok 1B MIMBALOT","DAÑO, JOSEPHINE M.","9351019750");
INSERT INTO tblpurok VALUES("39","Purok 2 MIMBALOT","ERMAC, CARMELITA M.","9553388211");
INSERT INTO tblpurok VALUES("40","Purok 3 MIMBALOT","ERSAN, ROLANDO T.","9555837136");
INSERT INTO tblpurok VALUES("41","Purok 4A MIMBALOT","CANILLAS, RICARDO B. JR.","9059748936");
INSERT INTO tblpurok VALUES("42","Purok 4B MIMBALOT","DIDATO, JOSE LOUGE C.","9551838323");
INSERT INTO tblpurok VALUES("43","Purok 5 BLISS MIMBALOT","CALING, CONDRADO C.","9362364003");
INSERT INTO tblpurok VALUES("44","Purok 1 TONGGO","CAOILE. GLORIA S.","9158544817");
INSERT INTO tblpurok VALUES("45","Purok 2 TONGGO","OLAYBAR, REMEDIOS Q.","9061361424");
INSERT INTO tblpurok VALUES("46","Purok 3 TONGGO","JOEL, OWAYAS B.","9559276132");
INSERT INTO tblpurok VALUES("47","Purok 3A ST. MICHAEL'S HEIGHTS","GWEN, LOMONGO","9457025548");



#
# Delete any existing table `tblresident`
#

DROP TABLE IF EXISTS `tblresident`;


#
# Table structure of table `tblresident`
#



CREATE TABLE `tblresident` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(100) DEFAULT NULL,
  `demographic_group` varchar(50) NOT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `picture` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `middlename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `skills` varchar(20) DEFAULT NULL,
  `birthplace` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civilstatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gender` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `purok` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `voterstatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `identified_as` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `resident_type` int(11) DEFAULT 1,
  `remarks` text DEFAULT NULL,
  `precinct_number` varchar(100) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=201 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO tblresident VALUES("189","06","Senior Citizen","Pilipino","15092024114117450191568_1015683769993133_4789656555843244787_n.jpg","Inoj","Q","Edullantes","Web Developer","Mimbalot","1998-10-20","26","Married","Male","Purok 1C MIMBALOT","Yes","Positive","","","","ILIGAN CITY, LANAO DEL NORTE","1","","A133","0");
INSERT INTO tblresident VALUES("183","01","PWDs","01","15092024103036120625174_2728860444023365_1066786861815184209_n.jpg","Kier","A","Libumfacil","Graphics Designer","CDO","2000-04-03","24","Widow","Male","Purok 7","Yes","Positive","","","","BARANGAY BURU-UN PRK7 ILIGAN CITY","1","","A166","0");
INSERT INTO tblresident VALUES("184","02","None","02","15092024103134328977383_195327203127818_8371700213489655448_n.jpg","Jeric","Z","Jemera","Graphics Designer","Linamon","2005-09-26","20","Single","Female","Purok 1-A","Yes","Positive","","","","BARANGAY BURU-UN PRK1 ILIGAN CITY","1","","A155","0");
INSERT INTO tblresident VALUES("185","03","PWDs","03","1509202410324011.jpg","Alinor","H","Taher","Graphics Designer","Marawi","2003-01-11","19","Single","Male","Purok 5 BLISS MIMBALOT","Yes","Unidentified","","",""," PRK6 MARAWI CITY","1","","A199","0");
INSERT INTO tblresident VALUES("186","04","ERPAT(BELA)","04","1509202410335719260562_673730366158664_4530295049818153536_n.jpg","Renato","O","Olivar","Senior Proggraming","Suarez","2006-06-25","18","Married","Male","Purok 4","Yes","Positive","","","","BARANGAY SUAREZ PRK4 ILIGAN CITY","1","","A177","0");
INSERT INTO tblresident VALUES("190","08","ERPAT(BELA)","Pilipino","1509202411420958375053_2272593652824313_7932486772427063296_n.jpg","Sherwin","Z","Etom","Graphics Designer","CDO","2000-01-20","24","Single","Male","Purok 8","Yes","Positive","09265986032","paradero3418@gmail.com","Online job","ILIGAN CITY, LANAO DEL NORTE","1","aw","A144","0");
INSERT INTO tblresident VALUES("188","0711","None","Pilipinos","15092024111932365925200_1208537457208963_250134892814528786_n.jpg","Faith","S","Arocha","Graphics Designer","Iligan City","2006-04-25","17","Single","Female","Purok 3 MIMBALOT","Yes","Positive","09265986032","paradero3418@gmail.com","Housekeeping","ILIGAN CITY PRK 7","1","COURSE BS INFORMATION","A122","0");
INSERT INTO tblresident VALUES("191","10","Senior Citizen","Pilipino","person.png","Dexter","L","Sevilla","Graphics Designer","Iligan","2001-05-23","23","Single","Male","Purok 8-A","Yes","Positive","","","","ILIGAN CITY PRK 8-A","1","","A1777","1");
INSERT INTO tblresident VALUES("181","0123456789","ERPAT(BELA)","Pilipino","15092024041325272888213_1118697002222793_4886443169141954643_n.jpg","Janrey","C","Paradero","Graphics Designer","Buru-un","2001-05-23","23","Single","Male","Purok 6","Yes","Positive","09265986032","","","Purok 8-A BURU-UN ILIGAN CITY","1","","A188","0");
INSERT INTO tblresident VALUES("198","012345566333","ERPAT(BELA)","American","person.png","JANFRES","Q","VLOG","HR","Mimbalot","2001-05-23","23","Married","Male","Purok 2 MIMBALOT","Yes","Positive","","","","Buru-un iligan city lanao del norte
Buru-un Iligan City Purok 8-A","1","","A1777","1");
INSERT INTO tblresident VALUES("199","0123456","Senior Citizen","arabp","person.png","JANREY","C","ETOM","HACKER","BURUUN","2001-05-23","23","Single","Male","Purok 3A ST. MICHAEL'S HEIGHTS","Yes","Positive","0955395","paradero78@gmail.com","sti","buruun ic","1","","0123","1");
INSERT INTO tblresident VALUES("200","01223366","None","Pilipino","13112024054701Male.jpg","JADE","C","PARADERO","COMPUTER LITERATE","BURUUN","2001-05-23","23","Single","Male","Purok 8-A","Yes","Positive","09265986032","paradero55@gmail.com","HACKER","Buru-un iligan city lanao del norte
Buru-un Iligan City Purok 8-A","1","","0112233","1");



#
# Delete any existing table `tblticket_logs`
#

DROP TABLE IF EXISTS `tblticket_logs`;


#
# Table structure of table `tblticket_logs`
#



CREATE TABLE `tblticket_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_number` int(11) DEFAULT NULL,
  `tracking_number` varchar(50) NOT NULL,
  `chosen_option` varchar(50) NOT NULL,
  `log_date` date NOT NULL,
  `log_time` time NOT NULL,
  `resident_id` int(1) NOT NULL,
  `priority` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(10) NOT NULL DEFAULT 'Pending',
  `is_removed` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblticket_logs VALUES("23","1","5D7D2DBCF7","Building Permit","2024-11-17","01:10:15","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("24","2","D651C514D4","Certificate Of Indigency","2024-11-17","01:14:54","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("25","3","6A73A2C17A","Certificate of Residency","2024-11-17","01:15:13","199","0","Pending","1");
INSERT INTO tblticket_logs VALUES("26","4","9B1CB18B00","Certificate of Residency","2024-11-17","01:17:18","198","0","Done","1");
INSERT INTO tblticket_logs VALUES("27","5","0F274A07D3","Barangay Certificate","2024-11-17","01:25:51","200","0","Pending","1");
INSERT INTO tblticket_logs VALUES("28","6","BBA56DE8C0","Business Permit","2024-11-17","01:25:55","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("29","7","CE12C8241B","Business Permit","2024-11-17","01:25:57","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("30","8","773C1CEF07","Business Permit","2024-11-17","01:25:58","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("31","9","AC01576E56","Business Permit","2024-11-17","01:26:00","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("32","10","4C923563F0","Business Permit","2024-11-17","01:26:02","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("33","11","F32FE6CB3B","Business Permit","2024-11-17","01:26:04","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("34","12","129A4BBC94","Business Permit","2024-11-17","01:26:06","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("35","13","B53D3AC55B","Business Permit","2024-11-17","01:26:08","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("36","14","04F62F04D0","Business Permit","2024-11-17","01:26:10","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("37","15","CBA2D47390","Business Permit","2024-11-17","01:26:11","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("38","16","DDE755B46F","Business Permit","2024-11-17","01:26:12","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("39","17","04C565C317","Business Permit","2024-11-17","01:26:13","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("40","18","92AB1C01EA","Business Permit","2024-11-17","01:26:14","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("41","19","4B47A50C81","Barangay Certificate","2024-11-17","01:26:19","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("42","20","1D4ED9065A","Barangay Certificate","2024-11-17","01:26:21","181","0","Pending","1");
INSERT INTO tblticket_logs VALUES("43","21","17BA657C49","Barangay Certificate","2024-11-17","01:26:24","186","0","Pending","1");
INSERT INTO tblticket_logs VALUES("44","22","398F32951C","Barangay Certificate","2024-11-17","01:26:28","198","0","Pending","1");
INSERT INTO tblticket_logs VALUES("45","23","C84C420E34","Barangay Certificate","2024-11-17","01:26:29","198","0","Pending","1");
INSERT INTO tblticket_logs VALUES("46","24","C1D33538B4","Barangay Certificate","2024-11-17","01:26:32","198","0","Pending","1");
INSERT INTO tblticket_logs VALUES("47","25","DD8225D68D","Barangay Certificate","2024-11-17","01:26:38","198","0","Pending","1");
INSERT INTO tblticket_logs VALUES("48","26","B0F7B9C1A9","Barangay Certificate","2024-11-17","01:26:40","198","0","Pending","1");
INSERT INTO tblticket_logs VALUES("49","27","F68C3E07C4","Barangay Certificate","2024-11-17","01:26:41","198","0","Pending","1");
INSERT INTO tblticket_logs VALUES("50","28","A624A2046F","Barangay Certificate","2024-11-17","01:26:42","198","0","Pending","1");
INSERT INTO tblticket_logs VALUES("51","29","6510C1134E","Barangay Certificate","2024-11-17","01:26:46","183","0","Pending","1");
INSERT INTO tblticket_logs VALUES("52","30","D6BB097DB3","Barangay Certificate","2024-11-17","01:26:47","183","0","Pending","1");
INSERT INTO tblticket_logs VALUES("53","31","FF08BE17B4","Barangay Certificate","2024-11-17","01:26:48","183","0","Pending","1");
INSERT INTO tblticket_logs VALUES("54","32","73EAA8B37D","Barangay Certificate","2024-11-17","01:26:49","183","0","Pending","1");
INSERT INTO tblticket_logs VALUES("55","33","8AA1E3D872","Barangay Certificate","2024-11-17","01:26:50","183","0","Pending","1");
INSERT INTO tblticket_logs VALUES("56","34","BEB55F8C4F","Barangay Certificate","2024-11-17","01:26:51","183","0","Pending","1");
INSERT INTO tblticket_logs VALUES("57","35","7CB78DDBC1","Barangay Certificate","2024-11-17","01:26:55","191","0","Pending","1");
INSERT INTO tblticket_logs VALUES("58","36","3E5652E2F1","Barangay Certificate","2024-11-17","01:26:57","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("59","37","9EFF581E21","Barangay Certificate","2024-11-17","01:26:59","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("60","38","CEBA2A6184","Barangay Certificate","2024-11-17","01:27:00","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("61","39","B66F919980","Barangay Certificate","2024-11-17","01:27:01","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("62","40","9081E215B5","Barangay Certificate","2024-11-17","01:27:02","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("63","41","6D30F804AD","Barangay Certificate","2024-11-17","01:27:03","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("64","42","993A626C01","Barangay Certificate","2024-11-17","01:27:06","191","0","Pending","1");
INSERT INTO tblticket_logs VALUES("65","43","0781A10952","Barangay Certificate","2024-11-17","01:27:07","191","0","Pending","1");
INSERT INTO tblticket_logs VALUES("66","44","AC1FEFBCEA","Barangay Certificate","2024-11-17","01:27:08","191","0","Pending","1");
INSERT INTO tblticket_logs VALUES("67","45","9EC62C873B","Barangay Certificate","2024-11-17","01:27:09","191","0","Pending","1");
INSERT INTO tblticket_logs VALUES("68","46","E841CA1D57","Barangay Certificate","2024-11-17","01:27:13","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("69","47","BD8F4A9969","Barangay Certificate","2024-11-17","01:27:14","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("70","48","0956D0AAA1","Barangay Certificate","2024-11-17","01:27:15","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("71","49","56B3B210EB","Barangay Certificate","2024-11-17","01:27:16","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("72","50","E8E459C12D","Barangay Certificate","2024-11-17","01:27:17","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("73","51","56F2AA78AD","Barangay Certificate","2024-11-17","01:27:19","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("74","52","56F2AA78AD","Barangay Certificate","2024-11-17","01:27:19","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("75","53","A2BBE66213","Barangay Certificate","2024-11-17","01:27:21","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("76","54","EAD039FF68","Barangay Certificate","2024-11-17","01:27:24","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("77","55","3C4A428FC4","Barangay Certificate","2024-11-17","01:27:29","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("78","56","61FA962E87","Barangay Certificate","2024-11-17","01:27:33","190","0","Pending","1");
INSERT INTO tblticket_logs VALUES("79","57","F0F1895ABC","Barangay Certificate","2024-11-17","01:27:38","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("80","58","33478BF79D","Barangay Certificate","2024-11-17","01:27:39","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("81","59","BFFD4D59EA","Barangay Certificate","2024-11-17","01:27:41","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("82","60","DA7CCAF2CE","Barangay Certificate","2024-11-17","01:27:43","188","0","Pending","1");
INSERT INTO tblticket_logs VALUES("83","1","FE629A0933","Barangay Certificate","2024-11-17","01:27:44","188","0","Pending","1");

