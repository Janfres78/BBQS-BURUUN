<?php 
	include '../server/server.php';

	if(!isset($_SESSION['username'])){
		if (isset($_SERVER["HTTP_REFERER"])) {
			header("Location: " . $_SERVER["HTTP_REFERER"]);
		}
	}

	$national_id      = $conn->real_escape_string($_POST['national']);
	$citizen          = $conn->real_escape_string($_POST['citizenship']);
	$fname            = $conn->real_escape_string($_POST['fname']);
	$mname            = $conn->real_escape_string($_POST['mname']);
	$lname            = $conn->real_escape_string($_POST['lname']);
	$skills           = $conn->real_escape_string($_POST['skills']);
	$precinct_number           = $conn->real_escape_string($_POST['precinct_number']);
	$bplace           = $conn->real_escape_string($_POST['bplace']);
	$bdate            = $conn->real_escape_string($_POST['bdate']);
	$age              = $conn->real_escape_string($_POST['age']);
	$category         = $conn->real_escape_string($_POST['category']);
	$cstatus          = $conn->real_escape_string($_POST['cstatus']);
	$gender           = $conn->real_escape_string($_POST['gender']);
	$purok            = $conn->real_escape_string($_POST['purok']);
	$vstatus          = $conn->real_escape_string($_POST['vstatus']);
	$indetity         = $conn->real_escape_string($_POST['indetity']);
	$email            = $conn->real_escape_string($_POST['email']);
	$number           = $conn->real_escape_string($_POST['number']);
	$occupation       = $conn->real_escape_string($_POST['occupation']);
	$address          = $conn->real_escape_string($_POST['address']);
	$profile          = $conn->real_escape_string($_POST['profileimg']); // base64 image
	$profile2         = $_FILES['img']['name'];  // File image
	
	// Change profile2 name if uploaded
	$newName = (!empty($profile2)) ? date('dmYHis').str_replace(" ", "", $profile2) : "";

	// Image file directory
  	$target = "../assets/uploads/resident_profile/".basename($newName);
	
	// Check if National ID already exists in the database
	$check = "SELECT id FROM tblresident WHERE national_id='$national_id'";
	$nat = $conn->query($check)->num_rows;

	if($nat == 0){  // National ID is unique
		if(!empty($fname)){

			// Handle if both base64 and file image exist
			if(!empty($profile) && !empty($profile2)){
				$query = "INSERT INTO tblresident (national_id, citizenship, picture, firstname, middlename, lastname, skills, precinct_number, birthplace, birthdate, age, demographic_group, civilstatus, gender, purok, voterstatus, identified_as, phone, email, occupation, address) 
						  VALUES ('$national_id', '$citizen', '$profile', '$fname', '$mname', '$lname', '$skills', '$precinct_number', '$bplace', '$bdate', $age, '$category', '$cstatus', '$gender', '$purok', '$vstatus', '$indetity', '$number', '$email', '$occupation', '$address')"; 

				if($conn->query($query) === true){
					$_SESSION['message'] = 'Resident Information has been saved!';
					$_SESSION['success'] = 'success';
				}
			}
			// Handle base64 image only
			else if(!empty($profile) && empty($profile2)){
				$query = "INSERT INTO tblresident (national_id, citizenship, picture, firstname, middlename, lastname, skills, precinct_number, birthplace, birthdate, age, demographic_group, civilstatus, gender, purok, voterstatus, identified_as, phone, email, occupation, address) 
						  VALUES ('$national_id', '$citizen', '$profile', '$fname', '$mname', '$lname', '$skills', '$precinct_number', '$bplace', '$bdate', $age, '$category', '$cstatus', '$gender', '$purok', '$vstatus', '$indetity', '$number', '$email', '$occupation', '$address')"; 

				if($conn->query($query) === true){
					$_SESSION['message'] = 'Resident Information has been saved!';
					$_SESSION['success'] = 'success';
				}
			}
			// Handle file image only
			else if(empty($profile) && !empty($profile2)){
				$query = "INSERT INTO tblresident (national_id, citizenship, picture, firstname, middlename, lastname, skills, precinct_number, birthplace, birthdate, age, demographic_group, civilstatus, gender, purok, voterstatus, identified_as, phone, email, occupation, address) 
						  VALUES ('$national_id', '$citizen', '$newName', '$fname', '$mname', '$lname', '$skills', '$precinct_number', '$bplace', '$bdate', $age, '$category', '$cstatus', '$gender', '$purok', '$vstatus', '$indetity', '$number', '$email', '$occupation', '$address')"; 

				if($conn->query($query) === true){
					$_SESSION['message'] = 'Resident Information has been saved!';
					$_SESSION['success'] = 'success';

					// Move the uploaded file
					if(move_uploaded_file($_FILES['img']['tmp_name'], $target)){
						$_SESSION['message'] = 'Resident Information has been saved!';
						$_SESSION['success'] = 'success';
					}
				}
			}
			// Handle no image (use default placeholder)
			else{
				$query = "INSERT INTO tblresident (national_id, citizenship, picture, firstname, middlename, lastname, skills, precinct_number, birthplace, birthdate, age, demographic_group, civilstatus, gender, purok, voterstatus, identified_as, phone, email, occupation, address) 
						  VALUES ('$national_id', '$citizen', 'person.png', '$fname', '$mname', '$lname', '$skills', '$precinct_number', '$bplace', '$bdate', $age, '$category', '$cstatus', '$gender', '$purok', '$vstatus', '$indetity', '$number', '$email', '$occupation', '$address')"; 

				if($conn->query($query) === true){
					$_SESSION['message'] = 'Resident Information has been saved!';
					$_SESSION['success'] = 'success';
				}
			}

		}else{
			$_SESSION['message'] = 'Please complete the form!';
			$_SESSION['success'] = 'danger';
		}
	}else{
		$_SESSION['message'] = 'National ID is already taken. Please enter a unique National ID!';
		$_SESSION['success'] = 'danger';
	}

	// Redirect to resident page
	header("Location: ../resident.php");
	$conn->close();
?>  
