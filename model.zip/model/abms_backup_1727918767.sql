# bbqs : MySQL database backup
#
# Generated: Thursday 3. October 2024
# Hostname: localhost
# Database: bbqs
# --------------------------------------------------------


#
# Delete any existing table `tbl_events`
#

DROP TABLE IF EXISTS `tbl_events`;


#
# Table structure of table `tbl_events`
#



CREATE TABLE `tbl_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_date` date NOT NULL,
  `event_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tbl_events VALUES("1","2024-08-20","STI");
INSERT INTO tbl_events VALUES("2","2024-09-27","ga");
INSERT INTO tbl_events VALUES("3","2024-09-26","JOSIN WAITING FOR BARANGAY CLEARANCE");
INSERT INTO tbl_events VALUES("4","2024-09-30","JERIC GETTING A TUPAD");
INSERT INTO tbl_events VALUES("5","2024-09-27","ETOM BIRTHDAY");
INSERT INTO tbl_events VALUES("6","2024-10-02","Seniors Pension");
INSERT INTO tbl_events VALUES("7","2024-10-03","Jeric 18th Birthday Debut");
INSERT INTO tbl_events VALUES("8","2024-10-17","EXAM");
INSERT INTO tbl_events VALUES("9","2024-10-16","EXAM");
INSERT INTO tbl_events VALUES("10","2024-10-15","EXAM");
INSERT INTO tbl_events VALUES("11","2024-10-01","JERIC LOVE JOSIN");



#
# Delete any existing table `tbl_support`
#

DROP TABLE IF EXISTS `tbl_support`;


#
# Table structure of table `tbl_support`
#



CREATE TABLE `tbl_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tbl_support VALUES("4","Janrey","paradero3418@gmail.com","09265986032","IT BARANGAY SUPPORT","OPERATION & MONITORING","2024-09-18 21:45:37");



#
# Delete any existing table `tbl_users`
#

DROP TABLE IF EXISTS `tbl_users`;


#
# Table structure of table `tbl_users`
#



CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `user_type` varchar(20) DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tbl_users VALUES("11","admin","d033e22ae348aeb5660fc2140aec35850c4da997","administrator","15092024114415bbic1.png","2021-05-03 10:33:03");
INSERT INTO tbl_users VALUES("15","Inoj","7c4a8d09ca3762af61e59520943dc26494f8941b","staff","15092024120926bbic1.png","2024-09-15 18:09:26");
INSERT INTO tbl_users VALUES("16","Janrey","7c4a8d09ca3762af61e59520943dc26494f8941b","administrator","22092024095343iligan.png","2024-09-22 15:53:43");



#
# Delete any existing table `tblblotter`
#

DROP TABLE IF EXISTS `tblblotter`;


#
# Table structure of table `tblblotter`
#



CREATE TABLE `tblblotter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `complainant` varchar(100) DEFAULT NULL,
  `respondent` varchar(100) DEFAULT NULL,
  `victim` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `details` varchar(10000) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO tblblotter VALUES("10","Joe Rizal","Nora Selos","Joe Rizal","Amicable","Pob 1 Catbalogan, Samar","2020-11-02","00:30:00"," Sustento sa Anaak ","Scheduled");
INSERT INTO tblblotter VALUES("16","Tiboy Tibo","Maria Advitos","Tiboy","Incident","Brgy1","2020-11-06","23:35:00","  Di alam ano pinag awayan  ","Scheduled");
INSERT INTO tblblotter VALUES("19","Girl Topak","Boy Topak","Girl Topak","Incident","Manila","2021-01-13","11:11:00","Mga Topakin na Pamilya","Settled");
INSERT INTO tblblotter VALUES("20","Kayzel","Mario","Kayzel","Incident","Quezon City","2021-01-07","00:12:00","Iwan Ko","Settled");
INSERT INTO tblblotter VALUES("22","Juan dela Cruz","Peter","Juan","Amicable","Manila","2021-01-01","22:16:00","   ayaw magbayad ng utang.. hehhheee   ","Active");
INSERT INTO tblblotter VALUES("26","Ron","Cajan","ROn Cajan","Amicable","Looc","2021-04-30","13:09:00","Donec sollicitudin molestie malesuada. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula.","Settled");



#
# Delete any existing table `tblbrgy_info`
#

DROP TABLE IF EXISTS `tblbrgy_info`;


#
# Table structure of table `tblbrgy_info`
#



CREATE TABLE `tblbrgy_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `province` varchar(100) DEFAULT NULL,
  `town` varchar(100) DEFAULT NULL,
  `brgy_name` varchar(50) DEFAULT NULL,
  `number` varchar(50) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `city_logo` varchar(100) DEFAULT NULL,
  `brgy_logo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblbrgy_info VALUES("1","Lanao del Norte ","Iligan City","Barangay Buru-un","09265986032","Buru-un  is a barangay of Iligan City in the province of Lanao del Norte within Region 10 (Northern Mindanao), Philippines.","15092024035002BB123.png","15092024035002iligan.png","15092024035002bbic1.png");



#
# Delete any existing table `tblchairmanship`
#

DROP TABLE IF EXISTS `tblchairmanship`;


#
# Table structure of table `tblchairmanship`
#



CREATE TABLE `tblchairmanship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblchairmanship VALUES("5","Committee on Health");
INSERT INTO tblchairmanship VALUES("6","Committee on Education");
INSERT INTO tblchairmanship VALUES("7","Committee on Rules");
INSERT INTO tblchairmanship VALUES("8","Committee on Infra");
INSERT INTO tblchairmanship VALUES("9","Committee on Solid Waste");
INSERT INTO tblchairmanship VALUES("10","Committee on Sports");
INSERT INTO tblchairmanship VALUES("12","No Chairmanship");



#
# Delete any existing table `tblofficials`
#

DROP TABLE IF EXISTS `tblofficials`;


#
# Table structure of table `tblofficials`
#



CREATE TABLE `tblofficials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `chairmanship` varchar(50) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `Contact Number` varchar(50) DEFAULT NULL,
  `termstart` date DEFAULT NULL,
  `termend` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblofficials VALUES("4","Brad Enoy","11","7","","2021-04-03","2025-12-31","Active");
INSERT INTO tblofficials VALUES("5","TATA CALLENO","11","8","","2021-04-03","2025-12-31","Active");
INSERT INTO tblofficials VALUES("6","ALAN BARINQUE","11","9","","2021-04-03","2025-12-31","Active");
INSERT INTO tblofficials VALUES("7","JAN NIKKO GERASTA","11","10","","2021-04-03","2025-12-31","Active");
INSERT INTO tblofficials VALUES("11","KARL LACIDA","11","14","","2021-04-03","2025-12-31","Active");
INSERT INTO tblofficials VALUES("14","MARIANITA B. PARADELA","2","4","","2024-09-15","2025-12-31","Active");
INSERT INTO tblofficials VALUES("17","MARIANITA B. PARADELA","12","4","","2024-09-01","2025-12-31","Active");
INSERT INTO tblofficials VALUES("18","ALAN BARINQUE","12","7","","2024-09-01","2025-12-31","Active");
INSERT INTO tblofficials VALUES("19","TATA CALLENO","12","8","","2024-09-01","2025-12-31","Active");
INSERT INTO tblofficials VALUES("20","Brad Enoy","12","9","","2024-09-01","2025-12-31","Active");
INSERT INTO tblofficials VALUES("21","KARL LACIDA","12","14","","2024-09-01","2025-12-31","Active");



#
# Delete any existing table `tblpayments`
#

DROP TABLE IF EXISTS `tblpayments`;


#
# Table structure of table `tblpayments`
#



CREATE TABLE `tblpayments` (
  `OR_No` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `details` varchar(100) DEFAULT NULL,
  `amounts` decimal(10,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblpayments VALUES("0","5","Business Permit Payment","7000.00","2021-05-19","admin"," Atrium Salon & Studio");
INSERT INTO tblpayments VALUES("0","6","Certificate of Indigency Payment","3500.00","2021-05-19","admin"," Ronil Gonzales Cajan");
INSERT INTO tblpayments VALUES("0","7","Barangay Clearance Payment","2500.00","2021-05-19","admin"," Ronil Poe Cajan");
INSERT INTO tblpayments VALUES("0","8","Business Permit Payment","3500.00","2021-05-18","admin"," Atrium Salon & Studio");
INSERT INTO tblpayments VALUES("0","9","Business Permit Payment","7000.00","2021-05-18","admin"," Atrium Salon & Studio");
INSERT INTO tblpayments VALUES("0","10","Business Permit Payment","7500.00","2021-05-18","admin"," Atrium Salon & Studio");
INSERT INTO tblpayments VALUES("0","11","Business Permit Payment","10.00","2024-09-15","admin"," Atrium Salon & Studio");
INSERT INTO tblpayments VALUES("0","12","Barangay Clearance Payment","10.00","2024-09-15","admin"," Ronil 213213 Cajan");
INSERT INTO tblpayments VALUES("0","13","Certificate of Indigency Payment","10.00","2024-09-15","admin"," Ronil 213213 Cajan");
INSERT INTO tblpayments VALUES("0","14","Business Permit Payment","10.00","2024-09-15","admin"," Atrium Salon & Studio");
INSERT INTO tblpayments VALUES("0","15","Barangay Clearance Payment","10.00","2024-09-15","admin"," Janrey C Paradero");
INSERT INTO tblpayments VALUES("0","16","Certificate of Indigency Payment","10.00","2024-09-15","admin"," Janrey C Paradero");
INSERT INTO tblpayments VALUES("0","17","Business Permit Payment","10.00","2024-09-15","admin"," <br />
<b>Warning</b>:  Trying to access array o");
INSERT INTO tblpayments VALUES("0","18","Business Permit Payment","10.00","2024-09-15","admin"," <br />
<b>Warning</b>:  Trying to access array o");
INSERT INTO tblpayments VALUES("0","19","Business Permit Payment","10.00","2024-09-15","admin"," <br />
<b>Warning</b>:  Undefined variable $perm");
INSERT INTO tblpayments VALUES("0","20","Business Permit Payment","10.00","2024-09-15","admin"," <br />
<b>Warning</b>:  Undefined variable $perm");
INSERT INTO tblpayments VALUES("0","21","Barangay Clearance Payment","10.00","2024-09-15","admin"," Ronil 213213 Cajan");
INSERT INTO tblpayments VALUES("0","22","Barangay Clearance Payment","20.00","2024-09-15","admin"," Janrey C Paradero");
INSERT INTO tblpayments VALUES("0","23","Certificate of Indigency Payment","20.00","2024-09-15","admin"," Janrey C Paradero");
INSERT INTO tblpayments VALUES("0","24","Business Permit Payment","20.00","2024-09-15","admin"," Atrium Salon & Studio");
INSERT INTO tblpayments VALUES("0","25","Barangay Clearance Payment","20.00","2024-09-15","admin"," Janrey C Paradero");
INSERT INTO tblpayments VALUES("0","26","Barangay Clearance Payment","20.00","2024-09-15","admin"," Inoj S Edullantes");
INSERT INTO tblpayments VALUES("0","27","Business Permit Payment","50.00","2024-09-15","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("0","28","Barangay Clearance Payment","30.00","2024-09-15","Inoj"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","29","Certificate of Indigency Payment","30.00","2024-09-15","Inoj"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","30","Barangay Clearance Payment","10.00","2024-09-15","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","31","Certificate of Indigency Payment","10.00","2024-09-15","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","32","Business Permit Payment","10.00","2024-09-15","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("0","33","Certificate of Indigency Payment","0.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","34","Certificate of Indigency Payment","100.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","35","Business Permit Payment","0.00","2024-09-16","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("0","36","Certificate of Indigency Payment","0.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","37","Certificate of Indigency Payment","0.00","2024-09-16","admin"," Inoj Q Edullantes");
INSERT INTO tblpayments VALUES("0","38","Barangay Clearance Payment","1000.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","39","Barangay Clearance Payment","20.00","2024-09-16","admin"," Inoj Q Edullantes");
INSERT INTO tblpayments VALUES("0","40","Business Permit Payment","20.00","2024-09-16","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("0","41","Barangay Clearance Payment","20.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","42","Certificate of Indigency Payment","220.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","43","Business Permit Payment","20.00","2024-09-16","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("0","44","Certificate of Indigency Payment","0.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","45","Certificate of Indigency Payment","20.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","46","Certificate of Indigency Payment","20.00","2024-09-16","Inoj"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","47","Barangay Clearance Payment","20.00","2024-09-16","Inoj"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","48","OR:01","0.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","49","Certificate of Indigency Payment","10.00","2024-09-16","Inoj"," Sherwin Z Etom");
INSERT INTO tblpayments VALUES("0","50","Barangay Clearance Payment","0.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0","51","Certificate of Indigency Payment","0.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("","52","Barangay Clearance Payment","10.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("","53","Business Permit Payment","10.00","2024-09-16","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("","54","Barangay Clearance Payment","600.00","2024-09-16","admin"," Alinor H Taher");
INSERT INTO tblpayments VALUES("123456","55","Barangay Clearance Payment","100.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("12333","56","Barangay Clearance Payment","100.00","2024-09-16","admin"," Janrey C Paradero");
INSERT INTO tblpayments VALUES("11002233445566","57","Barangay Clearance Payment","100.00","2024-09-16","admin"," Sherwin Z Etom");
INSERT INTO tblpayments VALUES("","58","Certificate of Indigency Payment","1000.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("","59","Business Permit Payment","2000.00","2024-09-16","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("","60","Business Permit Payment","100.00","2024-09-16","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("778899445566","61","Barangay Certificate Payment","120.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("","62","Certificate of Indigency Payment","150.00","2024-09-16","admin"," Jeric Z Jemera");
INSERT INTO tblpayments VALUES("","63","Certificate of Indigency Payment","250.00","2024-09-16","admin"," Jeric Z Jemera");
INSERT INTO tblpayments VALUES("","64","Certificate of Indigency Payment","450.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("00000123","65","Barangay Clearance Payment","500.00","2024-09-16","admin"," Dexter L Sevilla");
INSERT INTO tblpayments VALUES("","66","Certificate of Indigency Payment","600.00","2024-09-16","admin"," Inoj Q Edullantes");
INSERT INTO tblpayments VALUES("","67","Business Permit Payment","100.00","2024-09-16","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("123456","68","Barangay Clearance Payment","100.00","2024-09-16","admin"," Alinor H Taher");
INSERT INTO tblpayments VALUES("","69","Certificate of Indigency Payment","100.00","2024-09-16","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("BC0123","70","Barangay Clearance Payment","900.00","2024-09-16","admin"," Inoj Q Edullantes");
INSERT INTO tblpayments VALUES("COI789","71","Certificate of Indigency Payment","800.00","2024-09-16","admin"," Sherwin Z Etom");
INSERT INTO tblpayments VALUES("BPP055","72","Business Permit Payment","850.00","2024-09-16","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("0123","73","Business Permit Payment","1000.00","2024-09-18","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("1020","74","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("54465","75","Certificate of Indigency Payment","10.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("123","76","Certificate of Indigency Payment","0.00","2024-09-18","admin"," Sherwin Z Etom");
INSERT INTO tblpayments VALUES("COI","77","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","78","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("ASa","79","Business Permit Payment","10.00","2024-09-18","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("00000","80","Barangay Clearance Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("1000","81","Barangay Clearance Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("10101010","82","Barangay Clearance Payment","10.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("023","83","Certificate of Indigency Payment","1000.00","2024-09-18","admin"," Alinor H Taher");
INSERT INTO tblpayments VALUES("3636","84","Barangay Clearance Payment","100.00","2024-09-18","admin"," Inoj Q Edullantes");
INSERT INTO tblpayments VALUES("100","85","Barangay Clearance Payment","100.00","2024-09-18","admin"," Inoj Q Edullantes");
INSERT INTO tblpayments VALUES("2222","86","Certificate of Indigency Payment","123.00","2024-09-18","admin"," Jeric Z Jemera");
INSERT INTO tblpayments VALUES("asas","87","Certificate of Indigency Payment","1000.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("123456","88","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("123","89","Barangay Clearance Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("123","90","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("123456","91","Barangay Clearance Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("kl","92","Business Permit Payment","100.00","2024-09-18","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("100","93","Barangay Clearance Payment","100.00","2024-09-18","admin"," <br />
<b>Warning</b>:  Trying to access array o");
INSERT INTO tblpayments VALUES("100","94","Barangay Clearance Payment","100.00","2024-09-18","admin"," Kier A Libumfacil");
INSERT INTO tblpayments VALUES("03121","95","Certificate of Indigency Payment","1000.00","2024-09-18","admin"," Kier A Libumfacil");
INSERT INTO tblpayments VALUES("8","96","Certificate of Indigency Payment","55.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("123","97","Certificate of Indigency Payment","123.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","98","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","99","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("1","100","Barangay Clearance Payment","1.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","101","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","102","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","103","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("1","104","Certificate of Indigency Payment","1.00","2024-09-18","admin"," Sherwin Z Etom");
INSERT INTO tblpayments VALUES("11","105","Building Permit Payment","11.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","106","Business Permit Payment","100.00","2024-09-18","admin"," Inoj Q Edullantes");
INSERT INTO tblpayments VALUES("1","107","Business Permit Payment","1.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("2","108","Building Permit Payment","2.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("3","109","Certificate of Indigency Payment","3.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("4","110","Certificate of Residency Payment","4.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","111","Business Permit Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","112","Barangay Clearance Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","113","Certificate of Residency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","114","Certificate of Indigency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","115","Certificate of Residency Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","116","Building Permit Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("100","117","Barangay Clearance Payment","100.00","2024-09-18","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("1","118","Certificate of Indigency Payment","1.00","2024-09-18","Inoj"," Faith S Arocha");
INSERT INTO tblpayments VALUES("10","119","Certificate of Indigency Payment","10.00","2024-09-19","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("123456","120","Certificate of Residency Payment","12.00","2024-09-19","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("0123","121","Certificate of Residency Payment","100.00","2024-09-19","admin"," Dexter L Sevilla");
INSERT INTO tblpayments VALUES("123","122","Certificate of Indigency Payment","10.00","2024-09-20","admin"," Firbon Z Alinor");
INSERT INTO tblpayments VALUES("123","123","Certificate of Residency Payment","1.00","2024-09-22","admin"," Firbon Z Alinor");
INSERT INTO tblpayments VALUES("100","124","Barangay Clearance Payment","10.00","2024-09-22","admin"," Firbon Z Alinor");
INSERT INTO tblpayments VALUES("1236","125","Barangay Clearance Payment","10.00","2024-09-22","admin"," Firbon Z Alinor");
INSERT INTO tblpayments VALUES("BC","126","Barangay Clearance Payment","500.00","2024-09-22","admin"," Faith S Arocha");
INSERT INTO tblpayments VALUES("BCL123","127","Barangay Clearance Payment","125.00","2024-09-23","admin"," Firbon Z Alinor");
INSERT INTO tblpayments VALUES("56565","128","Barangay Clearance Payment","0.00","2024-09-23","admin"," Firbon Z Alinor");
INSERT INTO tblpayments VALUES("BCLEARANCE10","129","Barangay Clearance Payment","25.00","2024-09-26","admin"," Firbon Z Alinor");
INSERT INTO tblpayments VALUES("100ae","130","Business Permit Payment","25.00","2024-09-26","admin"," ETOM PAWNSHOP");
INSERT INTO tblpayments VALUES("COI123","131","Certificate of Indigency Payment","26.00","2024-09-27","admin"," Firbons Z Alinor");
INSERT INTO tblpayments VALUES("1","132","Barangay Clearance Payment","1.00","2024-10-02","admin"," Gerad S Abecia");
INSERT INTO tblpayments VALUES("1","133","Certificate of Indigency Payment","1.00","2024-10-02","admin"," Gerad S Abecia");
INSERT INTO tblpayments VALUES("2","134","Barangay Clearance Payment","2.00","2024-10-02","admin"," Gerad S Abecia");
INSERT INTO tblpayments VALUES("12","135","Certificate of Indigency Payment","12.00","2024-10-02","admin"," Jade S Paradero");
INSERT INTO tblpayments VALUES("11","136","Barangay Clearance Payment","11.00","2024-10-02","admin"," Gerad S Abecia");
INSERT INTO tblpayments VALUES("1","137","Barangay Clearance Payment","1.00","2024-10-02","admin"," Gerad S Abecia");
INSERT INTO tblpayments VALUES("1","138","Certificate of Residency Payment","1.00","2024-10-02","admin"," Gerad S Abecia");
INSERT INTO tblpayments VALUES("44","139","Certificate of Residency Payment","44.00","2024-10-02","admin"," Gerad S Abecia");



#
# Delete any existing table `tblpermit`
#

DROP TABLE IF EXISTS `tblpermit`;


#
# Table structure of table `tblpermit`
#



CREATE TABLE `tblpermit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `owner1` varchar(200) DEFAULT NULL,
  `owner2` varchar(80) DEFAULT NULL,
  `nature` varchar(220) DEFAULT NULL,
  `applied` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblpermit VALUES("6","ETOM PAWNSHOP","Sherwin Etom","","Tech","2024-09-15");



#
# Delete any existing table `tblposition`
#

DROP TABLE IF EXISTS `tblposition`;


#
# Table structure of table `tblposition`
#



CREATE TABLE `tblposition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` varchar(50) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblposition VALUES("4","Captain","1");
INSERT INTO tblposition VALUES("7","Councilor 1","2");
INSERT INTO tblposition VALUES("8","Councilor  2","3");
INSERT INTO tblposition VALUES("9","Councilor 3","4");
INSERT INTO tblposition VALUES("10","Councilor 4","5");
INSERT INTO tblposition VALUES("11","Councilor 5","6");
INSERT INTO tblposition VALUES("12","Councilor  6","7");
INSERT INTO tblposition VALUES("13","Councilor 7","8");
INSERT INTO tblposition VALUES("14","SK Chairman","9");
INSERT INTO tblposition VALUES("15","Secretary","10");
INSERT INTO tblposition VALUES("16","Treasurer","11");



#
# Delete any existing table `tblprecinct`
#

DROP TABLE IF EXISTS `tblprecinct`;


#
# Table structure of table `tblprecinct`
#



CREATE TABLE `tblprecinct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `precinct` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblprecinct VALUES("2","A0115","Purok 8-A");
INSERT INTO tblprecinct VALUES("4","B0116","Purok 6");
INSERT INTO tblprecinct VALUES("5","D09974","Purok 1-B");
INSERT INTO tblprecinct VALUES("6","Z3214","Purok 9");
INSERT INTO tblprecinct VALUES("7","Q0014","Elementary School");



#
# Delete any existing table `tblpurok`
#

DROP TABLE IF EXISTS `tblpurok`;


#
# Table structure of table `tblpurok`
#



CREATE TABLE `tblpurok` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblpurok VALUES("13","Purok 1","1");
INSERT INTO tblpurok VALUES("14","Purok 1-A","1-A");
INSERT INTO tblpurok VALUES("15","Purok 1-B","1-B");
INSERT INTO tblpurok VALUES("16","Purok 2","2");
INSERT INTO tblpurok VALUES("17","Purok 3","3");
INSERT INTO tblpurok VALUES("18","Purok 4","4");
INSERT INTO tblpurok VALUES("19","Purok 5","5");
INSERT INTO tblpurok VALUES("20","Purok 6","6");
INSERT INTO tblpurok VALUES("21","Purok 7","7");
INSERT INTO tblpurok VALUES("22","Purok 8","8");
INSERT INTO tblpurok VALUES("23","Purok 8-A","8-A");
INSERT INTO tblpurok VALUES("24","Purok 9","9");
INSERT INTO tblpurok VALUES("25","Purok 10","10");



#
# Delete any existing table `tblresident`
#

DROP TABLE IF EXISTS `tblresident`;


#
# Table structure of table `tblresident`
#



CREATE TABLE `tblresident` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(100) DEFAULT NULL,
  `demographic_group` varchar(50) NOT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `picture` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `middlename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Skills` varchar(20) DEFAULT NULL,
  `birthplace` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civilstatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gender` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `purok` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `voterstatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `identified_as` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `resident_type` int(11) DEFAULT 1,
  `remarks` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=198 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO tblresident VALUES("189","06","","Pilipino","15092024114117450191568_1015683769993133_4789656555843244787_n.jpg","Inoj","Q","Edullantes","Web Developer","Mimbalot","1998-10-20","26","Married","Male","Purok 1-B","Yes","Positive","","","","ILIGAN CITY, LANAO DEL NORTE","1","");
INSERT INTO tblresident VALUES("183","01","PWDs","01","15092024103036120625174_2728860444023365_1066786861815184209_n.jpg","Kier","A","Libumfacil","","CDO","2000-04-03","24","Widow","Male","Purok 7","Yes","Positive","","","","BARANGAY BURU-UN PRK7 ILIGAN CITY","1","");
INSERT INTO tblresident VALUES("184","02","","02","15092024103134328977383_195327203127818_8371700213489655448_n.jpg","Jeric","Z","Jemera","Junior Programmer ","Linamon","2005-09-26","20","Single","Female","Purok 1-A","Yes","Positive","","","","BARANGAY BURU-UN PRK1 ILIGAN CITY","1","");
INSERT INTO tblresident VALUES("185","03","","03","1509202410324011.jpg","Alinor","H","Taher","","Marawi","2003-01-11","19","Single","Male","Purok 6","Yes","Unidentified","","",""," PRK6 MARAWI CITY","1","");
INSERT INTO tblresident VALUES("186","04","None","04","1509202410335719260562_673730366158664_4530295049818153536_n.jpg","Renato","O","Olivar","","Suarez","2006-06-25","18","Married","Male","Purok 4","Yes","Positive","","","","BARANGAY SUAREZ PRK4 ILIGAN CITY","1","");
INSERT INTO tblresident VALUES("190","08","","Pilipino","1509202411420958375053_2272593652824313_7932486772427063296_n.jpg","Sherwin","Z","Etom","HR","CDO","2000-01-20","24","Single","Male","Purok 8","Yes","Positive","09265986032","paradero3418@gmail.com","Online job","ILIGAN CITY, LANAO DEL NORTE","1","aw");
INSERT INTO tblresident VALUES("188","07","","Pilipinos","15092024111932365925200_1208537457208963_250134892814528786_n.jpg","Faith","S","Arocha","Graphics Designer","Iligan City","2006-04-25","17","Single","Female","Purok 7","Yes","Positive","09265986032","paradero3418@gmail.com","Housekeeping","ILIGAN CITY PRK 7","1","COURSE BS INFORMATION");
INSERT INTO tblresident VALUES("191","10","","Pilipino","person.png","Dexter","L","Sevilla","","Iligan","2001-05-23","23","Single","Male","Purok 8-A","Yes","Positive","","","","ILIGAN CITY PRK 8-A","1","");
INSERT INTO tblresident VALUES("181","0123456789","","Pilipino","15092024041325272888213_1118697002222793_4886443169141954643_n.jpg","Janrey","C","Paradero","","Buru-un","2001-05-23","23","Single","Male","Purok 6","Yes","Positive","09265986032","","","Purok 8-A BURU-UN ILIGAN CITY","1","");
INSERT INTO tblresident VALUES("192","01236","PWDs","Pilipino","18092024130011wallpaperflare.com_wallpaper(5).jpg","Jade","S","Paradero","","Iligan City","2001-12-05","23","Single","Male","Purok 8-A","Yes","Positive","09265986032","paradero3418@gmail.com","Housekeeping","Buru-un iligan city lanao del norte
Buru-un Iligan City Purok 8-A","1","AKO");
INSERT INTO tblresident VALUES("193","112233445566","","Pilipino","person.png","JANFRES","Q","VLOG","","CDO","2001-02-03","23","Single","Female","Purok 2","Yes","Positive","","","","Buru-un iligan city lanao del norte
Buru-un Iligan City Purok 8-A","1","");
INSERT INTO tblresident VALUES("194","01236987","Senior Citizen","American","person.png","Firbons","Z","Alinor","","CDO","2001-05-23","63","Married","Male","Purok 9","Yes","Unidentified","09265986032","admin@gmail.com","Housekeeping","CDO, PUROK 9 KAUSWAGAN","1","");
INSERT INTO tblresident VALUES("195","00112233445566","","Arabo","28092024131910Untitleddesign.png","JANFREZZ","C","VLOG","","Linamon","2024-10-05","1","Married","Male","Purok 8-A","Yes","Positive","09265986032","admin@gmail.com","Traffic Enforcer","Buru-un iligan city lanao del norte
Buru-un Iligan City Purok 8-A","1","");
INSERT INTO tblresident VALUES("196","012345566333","Senior Citizen","Arabos","person.png","Gerad","S","Abecia","","Iligan City","2001-05-23","23","Single","Male","Purok 7","Yes","Positive","09265986032","paradero78@gmail.com","","Buru-un iligan city lanao del norte
Buru-un Iligan City Purok 8-A","1","");
INSERT INTO tblresident VALUES("197","0123456789101112","Senior Citizen","Arabo","02102024123900222.png","Noji","E. ","Etom","","CDO","2000-05-23","24","Married","Male","Purok 8-A","Yes","Positive","09265986032","paradero78@gmail.com","Driver","BURU-UN","1","");



#
# Delete any existing table `tblticket_logs`
#

DROP TABLE IF EXISTS `tblticket_logs`;


#
# Table structure of table `tblticket_logs`
#



CREATE TABLE `tblticket_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_number` int(11) DEFAULT NULL,
  `tracking_number` varchar(50) NOT NULL,
  `chosen_option` varchar(50) NOT NULL,
  `log_date` date NOT NULL,
  `log_time` time NOT NULL,
  `resident_id` int(1) NOT NULL,
  `priority` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tblticket_logs VALUES("1","0","2F93553712","Barangay Certificate","2024-10-02","05:58:25","189","1");
INSERT INTO tblticket_logs VALUES("2","0","BE9D18A1FC","Barangay Business Clearance","2024-10-02","05:58:33","185","0");
INSERT INTO tblticket_logs VALUES("3","0","01336005BB","Building Permit","2024-10-02","05:58:50","196","0");
INSERT INTO tblticket_logs VALUES("4","0","41E1E3CA5C","Barangay Certificate","2024-10-02","05:58:54","184","0");
INSERT INTO tblticket_logs VALUES("5","0","C7B8B45370","Barangay Certificate","2024-10-02","05:58:57","186","0");
INSERT INTO tblticket_logs VALUES("6","0","B8D79F9838","Business Permit","2024-10-02","07:28:19","181","1");

